// erp-backend/models/product.model.js
module.exports = (sequelize, DataTypes) => {
  const Product = sequelize.define('Product', {
    productId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    productName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    baseUnitId: { // [cite: 19]
      type: DataTypes.INTEGER,
      allowNull: true
    },
    // Kolom createdBy dan updatedBy
    createdBy: { // [cite: 19]
      type: DataTypes.INTEGER,
      allowNull: false
    },
    updatedBy: { // [cite: 19]
      type: DataTypes.INTEGER,
      allowNull: false
    }
  });

  Product.associate = (models) => { // [cite: 20]
    // Relasi many-to-many dengan Category
    Product.belongsToMany(models.Category, { // [cite: 20]
      through: 'ProductCategories',
      foreignKey: 'productId',
      otherKey: 'categoryId'
    });
    // Relasi dengan Base Unit
    Product.belongsTo(models.Unit, { // [cite: 21]
      as: 'BaseUnit',
      foreignKey: 'baseUnitId'
    });
    // Relasi many-to-many dengan Unit melalui ProductUnit
    Product.belongsToMany(models.Unit, { // [cite: 22]
      through: models.ProductUnit,
      foreignKey: 'productId',
      otherKey: 'unitId'
    });
    // Relasi hasMany ke ProductUnit
    Product.hasMany(models.ProductUnit, { // [cite: 23]
      foreignKey: 'productId'
    });
    // ========= TAMBAHAN UNTUK COMPONENTS ========= //
    // Relasi hasMany untuk komponen produk
    Product.hasMany(models.ProductComponent, { // [cite: 24]
      foreignKey: 'productId',
      as: 'Components'
    });
    // ============================================= //

    // Relasi pelacakan createdBy dan updatedBy
    Product.belongsTo(models.User, { // [cite: 25]
      as: 'Creator',
      foreignKey: 'createdBy'
    });
    Product.belongsTo(models.User, { // [cite: 26]
      as: 'Editor',
      foreignKey: 'updatedBy'
    });

     // --- TAMBAHKAN RELASI INI ---
    // Product bisa berada di banyak StoreProduct (One-to-Many dari Product ke StoreProduct)
    Product.hasMany(models.StoreProduct, {
        foreignKey: 'productId', // Foreign key in the StoreProduct table
        as: 'StoreProducts' // Alias for the relationship when including
    });
  };

  return Product;
};