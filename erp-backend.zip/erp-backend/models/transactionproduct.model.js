// erp-backend/models/transactionproduct.model.js
module.exports = (sequelize, DataTypes) => {
  const TransactionProduct = sequelize.define('TransactionProduct', {
    transactionProductId: { // Primary key for the junction table
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    // transactionId dan productId akan otomatis ditambahkan oleh Sequelize karena relasi
    quantity: { // Kuantitas produk dalam transaksi ini
      type: DataTypes.DECIMAL(10, 2), // Gunakan DECIMAL seperti di StoreProduct [cite: 49]
      allowNull: false,
      defaultValue: 0.00
    },
    price: { // Harga per unit produk dalam transaksi ini (opsional, tergantung transactionType)
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true // Misalnya, tidak ada harga di transaksi Transfer atau Adjustment
    },
    unitId: { // Unit yang digunakan untuk mencatat kuantitas di baris transaksi ini
        type: DataTypes.INTEGER,
        allowNull: true, // Allow null, jika kuantitas selalu dicatat dalam Base Unit produk
        references: { // Define foreign key constraint to Units table
            model: 'Units',
            key: 'unitId',
        }
    },
    // Kolom createdBy dan updatedBy untuk pelacakan
    createdBy: {
        type: DataTypes.INTEGER,
        allowNull: true // Sesuaikan dengan kebijakan non-nullability di model lain [cite: 44]
    },
    updatedBy: {
        type: DataTypes.INTEGER,
        allowNull: true // Sesuaikan dengan kebijakan non-nullability di model lain [cite: 44]
    }
  }, {
      // Composite unique key untuk memastikan hanya satu entri per Transaksi-Produk (-Unit jika perlu)
      uniqueKeys: {
          TransactionProductUnique: {
              // Jika kuantitas bisa dalam berbagai unit untuk produk yang sama dalam 1 transaksi,
              // sertakan unitId di unique key: fields: ['transactionId', 'productId', 'unitId']
              // Jika kuantitas selalu dalam Base Unit atau unit spesifik per produk per transaksi,
              // cukup transactionId dan productId:
              fields: ['transactionId', 'productId']
          }
      },
      timestamps: true // Enable createdAt and updatedAt [cite: 50]
  });

  TransactionProduct.associate = (models) => {
    // Relasi Many-to-One dengan Transaction
    TransactionProduct.belongsTo(models.Transaction, {
        foreignKey: 'transactionId',
        as: 'Transaction',
        onDelete: 'CASCADE' // Optional: Jika Transaksi dihapus, hapus entri TransactionProduct terkait
    });

    // Relasi Many-to-One dengan Product
    TransactionProduct.belongsTo(models.Product, {
        foreignKey: 'productId',
        as: 'Product',
        onDelete: 'CASCADE' // Optional: Jika Product dihapus, pertimbangkan aksi untuk TransactionProduct terkait (CASCADE, SET NULL, dll.)
    });

     // Relasi Many-to-One dengan Unit (unit yang digunakan di baris transaksi ini)
    TransactionProduct.belongsTo(models.Unit, {
        foreignKey: 'unitId',
        as: 'TransactionUnit' // Menggunakan alias berbeda dari BaseUnit atau ConvertedUnit
    });


    // Relasi pelacakan createdBy dan updatedBy
    TransactionProduct.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
    TransactionProduct.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });
  };

  return TransactionProduct;
};