// erp-backend/models/index.js
const Sequelize = require('sequelize');
const env = process.env.NODE_ENV || 'development';
const config = require(__dirname + '/../config/config.js')[env]; // [cite: 13]
const db = {};

const sequelize = new Sequelize(config.database, config.username, config.password, config); // [cite: 14]

// Import models
db.User = require('./user.model.js')(sequelize, Sequelize); // [cite: 14]
db.Product = require('./product.model.js')(sequelize, Sequelize); // [cite: 14]
db.Supplier = require('./supplier.model.js')(sequelize, Sequelize); // [cite: 15]
db.Category = require('./category.model.js')(sequelize, Sequelize); // [cite: 15]
db.Unit = require('./unit.model.js')(sequelize, Sequelize); // [cite: 15]
db.ProductUnit = require('./productunit.model.js')(sequelize, Sequelize); // [cite: 16]
db.ProductComponent = require('./productcomponent.model.js')(sequelize, Sequelize); // [cite: 16]
db.Store = require('./store.model.js')(sequelize, Sequelize); // [cite: 17]
db.StoreProduct = require('./storeproduct.model.js')(sequelize, Sequelize);
db.Customer = require('./customer.model.js')(sequelize, Sequelize);
// --- TAMBAHKAN BARIS INI UNTUK MODEL BARU ---
db.Transaction = require('./transaction.model.js')(sequelize, Sequelize);
db.TransactionProduct = require('./transactionproduct.model.js')(sequelize, Sequelize);

// Run associate function for each model to define relations
Object.keys(db).forEach(modelName => { // [cite: 17]
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize; // [cite: 18]
db.Sequelize = Sequelize; // [cite: 18]

module.exports = db;