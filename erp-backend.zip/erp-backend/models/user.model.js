// models/user.model.js
module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    username: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false
    },
    email: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false,
      validate: {
        isEmail: true
      }
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    role: {
      type: DataTypes.ENUM('Super', 'Manager', 'Admin', 'Operational', 'Guest'),
      allowNull: false,
      defaultValue: 'Guest'
    }
  });

  User.associate = (models) => {
    User.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
    User.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });
  };

  return User;
};