// models/supplier.model.js
module.exports = (sequelize, DataTypes) => {
  const Supplier = sequelize.define('Supplier', {
    supplierId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    supplierName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    supplierTelephone: {
      type: DataTypes.STRING
    }
    // Kolom createdAt dan updatedAt akan otomatis ditambahkan oleh Sequelize
    // jika opsi timestamps diaktifkan (defaultnya true)
  });

  // Tambahkan kolom createdBy dan updatedBy sebagai foreign key ke model User
  Supplier.associate = (models) => {
    Supplier.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
    Supplier.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });
  };

  return Supplier;
};