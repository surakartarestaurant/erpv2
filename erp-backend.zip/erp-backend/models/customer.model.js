// models/customer.model.js
module.exports = (sequelize, DataTypes) => {
  const Customer = sequelize.define('Customer', {
    customerId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    customerName: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    }
  });

  Customer.associate = (models) => {
    Customer.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
    Customer.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });
  };

  return Customer;
};