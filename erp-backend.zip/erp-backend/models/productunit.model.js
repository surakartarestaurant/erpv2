// models/productunit.model.js
module.exports = (sequelize, DataTypes) => {
  const ProductUnit = sequelize.define('ProductUnit', {
    productUnitId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    // productId dan unitId akan otomatis ditambahkan oleh Sequelize karena relasi
    conversionFactor: { // Faktor konversi dari unitId KE baseUnitId produk terkait
      type: DataTypes.DECIMAL,
      allowNull: false
    }
  });

  ProductUnit.associate = (models) => {
    // Relasi dengan Product
    ProductUnit.belongsTo(models.Product, { foreignKey: 'productId' });

    // Relasi dengan Unit (unit yang dikonversi)
    ProductUnit.belongsTo(models.Unit, { as: 'ConvertedUnit', foreignKey: 'unitId' });

    // Relasi pelacakan createdBy dan updatedBy
    ProductUnit.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
    ProductUnit.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });
  };

  return ProductUnit;
};