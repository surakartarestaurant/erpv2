// models/unit.model.js
module.exports = (sequelize, DataTypes) => {
    const Unit = sequelize.define('Unit', {
      unitId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      unitName: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
      }
    });
  
    Unit.associate = (models) => {
      // Relasi pelacakan createdBy dan updatedBy
      Unit.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
      Unit.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });
  
      // Relasi many-to-many dengan Product melalui ProductUnits (sebagai "unit yang dikonversi")
      Unit.belongsToMany(models.Product, {
          through: models.ProductUnit,
          foreignKey: 'unitId', // foreign key di tabel perantara yang mengacu ke Unit ini
          otherKey: 'productId' // foreign key di tabel perantara yang mengacu ke Product
      });
    };
  
    return Unit;
  };