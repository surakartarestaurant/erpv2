// erp-backend/models/storeproduct.model.js
module.exports = (sequelize, DataTypes) => {
  const StoreProduct = sequelize.define('StoreProduct', {
    storeProductId: { // Primary key for the junction table (optional, but recommended)
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    // Sequelize will automatically add storeId and productId as foreign keys
    // because we define Many-to-Many associations in models/index.js or via belongsTo/hasMany

    quantity: { // Column to store the quantity of the Product in the Store
      type: DataTypes.DECIMAL(10, 2), // Use DECIMAL for potentially decimal quantities
      allowNull: false,
      defaultValue: 0.00
    },
    // Add createdBy and updatedBy if you want to track the user who managed the stock entry
    createdBy: {
        type: DataTypes.INTEGER,
        allowNull: true // Allow null if not always tracked or for initial data
    },
    updatedBy: {
        type: DataTypes.INTEGER,
        allowNull: true // Allow null
    }
  }, {
      // Optional: Composite unique key to ensure only one entry per Store-Product
      uniqueKeys: {
          StoreProductUnique: {
              fields: ['storeId', 'productId']
          }
      },
      timestamps: true // Enable timestamps for createdAt and updatedAt
  });

  // Define associations here, even though they are called from index.js
  StoreProduct.associate = (models) => {
    // StoreProduct belongs to Store (Many-to-One from StoreProduct to Store)
    StoreProduct.belongsTo(models.Store, {
      foreignKey: 'storeId',
      as: 'Store', // Alias for the relationship
      onDelete: 'CASCADE' // Optional: If Store is deleted, delete related StoreProduct entries
    });

    // StoreProduct belongs to Product (Many-to-One from StoreProduct to Product)
    StoreProduct.belongsTo(models.Product, {
      foreignKey: 'productId',
      as: 'Product', // Alias for the relationship
      onDelete: 'CASCADE' // Optional: If Product is deleted, delete related StoreProduct entries
    });

    // Tracking relationships for createdBy and updatedBy
    StoreProduct.belongsTo(models.User, {
        as: 'Creator',
        foreignKey: 'createdBy'
    });
    StoreProduct.belongsTo(models.User, {
        as: 'Editor',
        foreignKey: 'updatedBy'
    });
  };

  return StoreProduct;
};