// models/productcomponent.model.js
module.exports = (sequelize, DataTypes) => {
  const ProductComponent = sequelize.define('ProductComponent', {
    productComponentId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    productId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Products',
        key: 'productId'
      }
    },
    componentId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Products',
        key: 'productId'
      }
    },
    quantity: {
      type: DataTypes.DECIMAL(26, 16),
      allowNull: false,
      defaultValue: 1.00
    },
    createdBy: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    updatedBy: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    timestamps: true,
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  });

  ProductComponent.associate = (models) => {
    // Relasi ke Product sebagai produk utama
    ProductComponent.belongsTo(models.Product, {
      foreignKey: 'productId',
      as: 'MainProduct',
      onDelete: 'CASCADE'
    });

    // Relasi ke Product sebagai komponen
    ProductComponent.belongsTo(models.Product, {
      foreignKey: 'componentId',
      as: 'Component',
      onDelete: 'CASCADE'
    });

    // Pelacakan createdBy dan updatedBy
    ProductComponent.belongsTo(models.User, { 
      as: 'Creator',
      foreignKey: 'createdBy'
    });
    
    ProductComponent.belongsTo(models.User, { 
      as: 'Editor',
      foreignKey: 'updatedBy'
    });
  };

  return ProductComponent;
};