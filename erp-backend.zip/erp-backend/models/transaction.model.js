// erp-backend/models/transaction.model.js
module.exports = (sequelize, DataTypes) => {
  const Transaction = sequelize.define('Transaction', {
    transactionId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    transactionType: {
      type: DataTypes.ENUM('Purchase', 'Sale', 'Request', 'Transfer', 'Adjustment'),
      allowNull: false
    },
    storeId: { // Store asal transaksi
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { // Define foreign key constraint at DB level for the originating store
          model: 'Stores', // Name of the target table
          key: 'storeId', // Key in the target table
      }
    },
    // counterpartyId dan counterpartyType untuk asosiasi polimorfik (handled at app level)
    counterpartyId: {
        type: DataTypes.INTEGER, // Menggunakan tipe INTEGER, sesuaikan jika ID Store/Supplier/Customer adalah UUID
        allowNull: true // Allow null if some transaction types don't have a counterparty (e.g., internal adjustment not linked to another entity)
    },
    counterpartyType: {
        type: DataTypes.ENUM('Store', 'Supplier', 'Customer'),
        allowNull: true // Allow null if some transaction types don't have a counterparty
    },
    // Tambahkan kolom lain yang relevan seperti transactionDate, totalAmount, notes, dll.
    transactionDate: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    notes: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    // Kolom createdBy dan updatedBy untuk pelacakan
    createdBy: {
        type: DataTypes.INTEGER,
        allowNull: true // Sesuaikan dengan kebijakan non-nullability di model lain [cite: 44]
    },
    updatedBy: {
        type: DataTypes.INTEGER,
        allowNull: true // Sesuaikan dengan kebijakan non-nullability di model lain [cite: 44]
    }
  }, {
      // Optional: Add indexes for storeId, counterpartyId, counterpartyType for faster queries
      indexes: [
          { fields: ['storeId'] },
          { fields: ['counterpartyId', 'counterpartyType'] },
      ]
  });

  Transaction.associate = (models) => {
    // Relasi Many-to-One dengan Store (Store asal transaksi)
    Transaction.belongsTo(models.Store, {
        as: 'OriginatingStore',
        foreignKey: 'storeId'
    });

    // Relasi One-to-Many dengan TransactionProduct
    Transaction.hasMany(models.TransactionProduct, {
        foreignKey: 'transactionId',
        as: 'TransactionProducts'
    });

    // Relasi pelacakan createdBy dan updatedBy
    Transaction.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
    Transaction.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });

    // Catatan: Relasi counterparty (Store, Supplier, Customer) akan ditangani di level aplikasi/controller
    // dengan melakukan JOIN kondisional berdasarkan counterpartyType.
    // Tidak didefinisikan sebagai asosiasi foreign key langsung di sini.
  };

  return Transaction;
};