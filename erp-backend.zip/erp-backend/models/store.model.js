// erp-backend/models/store.model.js
module.exports = (sequelize, DataTypes) => {
  const Store = sequelize.define('Store', {
    storeId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    storeName: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    // Kolom createdBy dan updatedBy diasumsikan ada atau ditambahkan
    createdBy: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    updatedBy: {
      type: DataTypes.INTEGER,
      allowNull: true
    }
  });

  Store.associate = (models) => { // [cite: 47]
    // Relasi pelacakan createdBy dan updatedBy
    Store.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' }); // [cite: 47]
    Store.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' }); // [cite: 48]

    // --- TAMBAHKAN RELASI INI ---
    // Store memiliki banyak StoreProduct (One-to-Many dari Store ke StoreProduct)
    Store.hasMany(models.StoreProduct, {
        foreignKey: 'storeId', // Foreign key in the StoreProduct table
        as: 'StoreProducts' // Alias for the relationship when including
    });
  };

  return Store;
};