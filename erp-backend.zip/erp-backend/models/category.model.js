// models/category.model.js
module.exports = (sequelize, DataTypes) => {
  const Category = sequelize.define('Category', {
    categoryId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    categoryName: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    }
    // Kolom createdAt dan updatedAt akan otomatis ditambahkan oleh Sequelize
    // jika opsi timestamps diaktifkan (defaultnya true)
  });

  Category.associate = (models) => {
    // Relasi many-to-many dengan Product melalui tabel ProductCategories
    Category.belongsToMany(models.Product, {
      through: 'ProductCategories', // Nama tabel perantara
      foreignKey: 'categoryId',    // Nama foreign key di tabel perantara yang mengacu ke Category
      otherKey: 'productId'      // Nama foreign key di tabel perantara yang mengacu ke Product
    });
    // Tambahkan relasi pelacakan createdBy dan updatedBy jika Anda ingin Category juga dilacak
    Category.belongsTo(models.User, { as: 'Creator', foreignKey: 'createdBy' });
    Category.belongsTo(models.User, { as: 'Editor', foreignKey: 'updatedBy' });
  };

  return Category;
};