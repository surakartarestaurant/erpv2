// erp-backend/controllers/transaction.controller.js
const db = require("../models");
const Transaction = db.Transaction;
const TransactionProduct = db.TransactionProduct; // Diperlukan untuk include
const Store = db.Store; // Diperlukan untuk include dan validasi counterparty
const Supplier = db.Supplier; // Diperlukan untuk validasi counterparty
const Customer = db.Customer; // Diperlukan untuk validasi counterparty
const User = db.User; // Diperlukan untuk include createdBy/updatedBy

const paginateAndSearch = require('../utils/paginationAndSearch'); // Jika ingin menggunakan pagination/search di findAll

// Helper function to validate counterparty
const validateCounterparty = async (counterpartyId, counterpartyType) => {
    if (!counterpartyId || !counterpartyType) {
        return { isValid: true, message: null }; // Counterparty is optional, or validation not needed if both are null
    }

    let counterparty = null;
    switch (counterpartyType) {
        case 'Store':
            counterparty = await Store.findByPk(counterpartyId);
            if (!counterparty) return { isValid: false, message: `Store with id=${counterpartyId} not found.` };
            break;
        case 'Supplier':
            counterparty = await Supplier.findByPk(counterpartyId);
             if (!counterparty) return { isValid: false, message: `Supplier with id=${counterpartyId} not found.` };
            break;
        case 'Customer':
            counterparty = await Customer.findByPk(counterpartyId);
             if (!counterparty) return { isValid: false, message: `Customer with id=${counterpartyId} not found.` };
            break;
        default:
            return { isValid: false, message: `Invalid counterparty type: ${counterpartyType}.` };
    }
    return { isValid: true, message: null, counterparty: counterparty };
};


// Create and Save a new Transaction
exports.create = async (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const { transactionType, storeId, counterpartyId, counterpartyType, transactionDate, notes, transactionProducts } = req.body;

    // Basic validation
    if (!transactionType || !storeId) {
        return res.status(400).send({ message: "Transaction type and originating store ID cannot be empty!" });
    }

    // Validate Originating Store
    const originatingStore = await Store.findByPk(storeId);
    if (!originatingStore) {
        return res.status(404).send({ message: `Originating Store with id=${storeId} not found.` });
    }

    // Validate Counterparty if provided
    if (counterpartyId || counterpartyType) {
        const counterpartyValidation = await validateCounterparty(counterpartyId, counterpartyType);
        if (!counterpartyValidation.isValid) {
            return res.status(400).send({ message: counterpartyValidation.message });
        }
         // Optional: Add more specific validation based on transactionType and counterpartyType
         // e.g., If type is 'Purchase', counterparty must be 'Supplier'.
    }


    const transaction = {
        transactionType: transactionType,
        storeId: storeId,
        counterpartyId: counterpartyId || null, // Set to null if not provided
        counterpartyType: counterpartyType || null, // Set to null if not provided
        transactionDate: transactionDate || new Date(), // Use provided date or current date
        notes: notes,
        createdBy: req.userId,
        updatedBy: req.userId
    };

    try {
        // Start a transaction to ensure atomicity if creating related transactionProducts
        const result = await db.sequelize.transaction(async (t) => {
            const newTransaction = await Transaction.create(transaction, { transaction: t });

            // If transactionProducts are provided, create them
            if (transactionProducts && Array.isArray(transactionProducts) && transactionProducts.length > 0) {
                 // Basic validation for transaction products (can be expanded)
                 for (const item of transactionProducts) {
                     if (!item.productId || item.quantity === undefined || item.quantity === null || item.quantity < 0) {
                         throw new Error("Invalid transaction product data: productId and quantity are required and quantity must be >= 0.");
                     }
                      // Optional: Validate unitId if provided
                      if (item.unitId) {
                          const unitExists = await db.Unit.findByPk(item.unitId, { transaction: t });
                          if (!unitExists) {
                              throw new Error(`Unit with id=${item.unitId} not found for a transaction product.`);
                          }
                      }
                       // Optional: Check if productId exists
                       const productExists = await db.Product.findByPk(item.productId, { transaction: t });
                       if (!productExists) {
                           throw new Error(`Product with id=${item.productId} not found for a transaction product.`);
                       }
                 }

                const productsToCreate = transactionProducts.map(item => ({
                    ...item,
                    transactionId: newTransaction.transactionId,
                    createdBy: req.userId,
                    updatedBy: req.userId
                }));
                await TransactionProduct.bulkCreate(productsToCreate, { transaction: t });
            }

            return newTransaction; // Return the created transaction
        });


        // Fetch the created transaction with relations for response
        const createdTransaction = await Transaction.findByPk(result.transactionId, {
            include: [
                { model: Store, as: 'OriginatingStore', attributes: ['storeId', 'storeName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] },
                 { // Include Transaction Products and their related Product and Unit
                    model: TransactionProduct,
                    as: 'TransactionProducts',
                     include: [
                         { model: db.Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'] },
                         { model: db.Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] }
                     ]
                 }
            ]
        });

        // Dynamically fetch counterparty details
        let counterpartyDetails = null;
         if (createdTransaction.counterpartyId && createdTransaction.counterpartyType) {
             const counterpartyValidation = await validateCounterparty(createdTransaction.counterpartyId, createdTransaction.counterpartyType);
             if (counterpartyValidation.isValid) {
                 counterpartyDetails = counterpartyValidation.counterparty;
             }
         }


        // Add counterpartyDetails to the response object
        const responseData = {
            ...createdTransaction.get({ plain: true }), // Get plain object
            Counterparty: counterpartyDetails // Attach the fetched counterparty
        };


        res.status(201).send(responseData);

    } catch (err) {
        console.error("Error creating Transaction:", err);
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Transaction."
        });
    }
};

// Retrieve all Transactions with pagination and search
exports.findAll = async (req, res) => {
    // Define fields that can be searched. Could be transaction type, notes, maybe store name?
    // Searching related models often requires more complex joins, may exclude related fields for simple text search
    const searchableFields = ['transactionType', 'notes'];
    const options = {
        order: [['transactionDate', 'DESC']], // Order by transaction date
        include: [
             { model: Store, as: 'OriginatingStore', attributes: ['storeId', 'storeName'] },
             { model: User, as: 'Creator', attributes: ['id', 'username'] },
             { model: User, as: 'Editor', attributes: ['id', 'username'] },
             // Including TransactionProducts in findAll might be too much data.
             // It's better to include them only in findOne detail view.
             // {
             //    model: TransactionProduct,
             //    as: 'TransactionProducts',
             //     include: [
             //         { model: db.Product, as: 'Product', attributes: ['productId', 'productName'] },
             //         { model: db.Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] }
             //     ]
             // }
        ]
    };

    try {
        // If you need to search by related fields (like store name, supplier name, etc.),
        // you'd need to adjust the where condition and includes in paginateAndSearch
        // or handle the search logic manually here.
        const result = await paginateAndSearch(Transaction, req.query, searchableFields, options);

         // Optional: For each transaction in the result, dynamically fetch counterparty.
         // This can be inefficient for large lists. Consider fetching counterparty only in findOne.
         // Or, adjust the frontend to fetch counterparty details when a transaction row is selected/expanded.
        const transactionsWithCounterparties = await Promise.all(result.items.map(async (transaction) => {
             let counterpartyDetails = null;
             if (transaction.counterpartyId && transaction.counterpartyType) {
                 const counterpartyValidation = await validateCounterparty(transaction.counterpartyId, transaction.counterpartyType);
                 if (counterpartyValidation.isValid) {
                     counterpartyDetails = counterpartyValidation.counterparty;
                 }
             }
             return {
                 ...transaction.get({ plain: true }),
                 Counterparty: counterpartyDetails // Attach counterparty details
             };
         }));


        res.send({
            items: transactionsWithCounterparties, // Send the items with counterparty details
            totalItems: result.totalItems,
            currentPage: result.currentPage,
            totalPages: result.totalPages
        });

    } catch (err) {
        console.error("Error retrieving Transactions:", err);
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving transactions."
        });
    }
};

// Find a single Transaction with an id
exports.findOne = async (req, res) => {
    const id = req.params.id; // This is the transactionId

    try {
        const transaction = await Transaction.findByPk(id, {
            include: [
                { model: Store, as: 'OriginatingStore', attributes: ['storeId', 'storeName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] },
                 { // Include Transaction Products and their related Product and Unit
                    model: TransactionProduct,
                    as: 'TransactionProducts',
                     include: [
                         { model: db.Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'] },
                         { model: db.Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] }
                     ]
                 }
                // Do NOT include counterparty here directly as it's polymorphic.
                // Fetch it dynamically below.
            ]
        });

        if (!transaction) {
            return res.status(404).send({ message: `Cannot find Transaction with id=${id}.` });
        }

        // Dynamically fetch counterparty details based on type and ID
        let counterpartyDetails = null;
        if (transaction.counterpartyId && transaction.counterpartyType) {
             const counterpartyValidation = await validateCounterparty(transaction.counterpartyId, transaction.counterpartyType);
             if (counterpartyValidation.isValid) {
                 // Select specific attributes to avoid sending sensitive info like passwords
                 const counterpartyAttributes = ['id', 'storeId', 'supplierId', 'customerId', 'storeName', 'supplierName', 'customerName']; // Add/adjust attributes based on your models
                 counterpartyDetails = counterpartyValidation.counterparty ?
                                       counterpartyValidation.counterparty.get({ plain: true, attributes: counterpartyAttributes }) :
                                       null;
             }
        }

         // Construct the response object, adding the dynamically fetched counterparty
        const responseData = {
            ...transaction.get({ plain: true }), // Get plain object of the transaction
            Counterparty: counterpartyDetails // Attach the fetched counterparty details
        };


        res.send(responseData);

    } catch (err) {
        console.error("Error retrieving Transaction:", err);
        res.status(500).send({
            message: "Error retrieving Transaction with id=" + id
        });
    }
};

// Update a Transaction by the id in the request
exports.update = async (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const id = req.params.id; // This is the transactionId
    const updateData = { ...req.body }; // Copy body data
    updateData.updatedBy = req.userId; // Set updatedBy

    // Do not allow changing the originating storeId after creation? Or allow with validation?
    // For now, let's allow but validate if included.
     if (updateData.storeId) {
        const originatingStore = await Store.findByPk(updateData.storeId);
        if (!originatingStore) {
            return res.status(404).send({ message: `Originating Store with id=${updateData.storeId} not found.` });
        }
     }

    // Validate Counterparty if provided in update data
    if (updateData.counterpartyId !== undefined || updateData.counterpartyType !== undefined) {
         // Need to get the *current* counterpartyType/Id if they are not both provided in the update data
         let currentTransaction = await Transaction.findByPk(id, { attributes: ['counterpartyId', 'counterpartyType'] });
         if (!currentTransaction) {
             return res.status(404).send({ message: `Cannot update Transaction with id=${id}. Transaction not found!` });
         }

         const finalCounterpartyId = updateData.counterpartyId !== undefined ? updateData.counterpartyId : currentTransaction.counterpartyId;
         const finalCounterpartyType = updateData.counterpartyType !== undefined ? updateData.counterpartyType : currentTransaction.counterpartyType;

         if (finalCounterpartyId || finalCounterpartyType) { // Only validate if counterparty is actually being set (not both null)
              const counterpartyValidation = await validateCounterparty(finalCounterpartyId, finalCounterpartyType);
              if (!counterpartyValidation.isValid) {
                  return res.status(400).send({ message: counterpartyValidation.message });
              }
               // Optional: More specific validation based on transactionType (if type is also being updated or remains certain type)
         }
         // Ensure both counterpartyId and counterpartyType are updated together if one is nulling out
          if (updateData.counterpartyId === null && updateData.counterpartyType !== undefined) {
               updateData.counterpartyType = null;
          }
           if (updateData.counterpartyType === null && updateData.counterpartyId !== undefined) {
               updateData.counterpartyId = null;
           }
    }


    try {
        // Note: Updating transaction products should ideally be handled via separate endpoints
        // (create/update/delete on /api/transaction-products).
        // This update function focuses only on the Transaction header data.

        const num = await Transaction.update(updateData, {
            where: { transactionId: id }
        });

        if (num == 1) {
             // Fetch the updated transaction to return the latest data
             const updatedTransaction = await Transaction.findByPk(id, {
                 include: [
                     { model: Store, as: 'OriginatingStore', attributes: ['storeId', 'storeName'] },
                     { model: User, as: 'Creator', attributes: ['id', 'username'] },
                     { model: User, as: 'Editor', attributes: ['id', 'username'] },
                      { // Include Transaction Products if needed in update response
                        model: TransactionProduct,
                        as: 'TransactionProducts',
                         include: [
                             { model: db.Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'] },
                             { model: db.Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] }
                         ]
                     }
                 ]
             });

             // Dynamically fetch counterparty for the updated transaction
             let counterpartyDetails = null;
             if (updatedTransaction.counterpartyId && updatedTransaction.counterpartyType) {
                  const counterpartyValidation = await validateCounterparty(updatedTransaction.counterpartyId, updatedTransaction.counterpartyType);
                  if (counterpartyValidation.isValid) {
                      const counterpartyAttributes = ['id', 'storeId', 'supplierId', 'customerId', 'storeName', 'supplierName', 'customerName']; // Add/adjust attributes
                      counterpartyDetails = counterpartyValidation.counterparty ?
                                            counterpartyValidation.counterparty.get({ plain: true, attributes: counterpartyAttributes }) :
                                            null;
                  }
             }

             const responseData = {
                ...updatedTransaction.get({ plain: true }),
                Counterparty: counterpartyDetails
             };

            res.send(responseData); // Send the updated object with counterparty

        } else {
            res.status(404).send({ // Use 404 if the item was not found
                message: `Cannot update Transaction with id=${id}. Maybe Transaction was not found or req.body is empty!`
            });
        }
    } catch (err) {
        console.error("Error updating Transaction:", err);
        res.status(500).send({
            message: "Error updating Transaction with id=" + id
        });
    }
};

// Delete a Transaction with the specified id
exports.delete = async (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const id = req.params.id; // This is the transactionId

    try {
        // Deleting a transaction will automatically trigger deletion of associated TransactionProducts
        // if `onDelete: 'CASCADE'` is set on the foreign key in the TransactionProduct model.
        const num = await Transaction.destroy({
            where: { transactionId: id }
        });

        if (num == 1) {
            res.send({
                message: "Transaction was deleted successfully!"
            });
        } else {
            res.status(404).send({ // Use 404 if the item was not found
                message: `Cannot delete Transaction with id=${id}. Maybe it was not found!`
            });
        }
    } catch (err) {
        console.error("Error deleting Transaction:", err);
        res.status(500).send({
            message: "Could not delete Transaction with id=" + id
        });
    }
};

// Delete all Transactions from the database
exports.deleteAll = async (req, res) => {
     if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }
    // Note: Deleting all transactions will also delete all transaction products if cascade delete is set.
    try {
        const nums = await Transaction.destroy({
            where: {},
            truncate: false // Set truncate: true if you want to reset auto-increment ID (caution!)
        });

        res.send({ message: `${nums} Transactions were deleted successfully!` });

    } catch (err) {
         console.error("Error deleting all Transactions:", err);
        res.status(500).send({
            message: err.message || "Some error occurred while removing all transactions."
        });
    }
};