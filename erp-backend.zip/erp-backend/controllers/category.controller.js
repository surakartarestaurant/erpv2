// controllers/category.controller.js
const db = require("../models");
const Category = db.Category;
const User = db.User; // Import model User untuk include

const paginateAndSearch = require('../utils/paginationAndSearch');

// Create and Save a new Category
exports.create = (req, res) => {
  // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  if (!req.body.categoryName) {
    res.status(400).send({
      message: "Category name can not be empty!"
    });
    return;
  }

  const category = {
    categoryName: req.body.categoryName,
    createdBy: req.userId, // Set createdBy dengan ID pengguna yang sedang login
    updatedBy: req.userId  // Set updatedBy dengan ID pengguna yang sedang login saat pertama dibuat
  };

  Category.create(category)
    .then(data => {
      res.status(201).send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Category."
      });
    });
};

// Retrieve all Categories with pagination and search
exports.findAll = async (req, res) => {
  const searchableFields = ['categoryName'];
  const options = {
    order: [['categoryId', 'ASC']]
    // Tidak perlu include User di sini jika tidak ditampilkan di daftar
  };

  try {
    const result = await paginateAndSearch(Category, req.query, searchableFields, options);
    res.send({
      items: result.items,
      totalItems: result.totalItems,
      currentPage: result.currentPage,
      totalPages: result.totalPages
    });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving categories."
    });
  }
};

// Find a single Category with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  Category.findByPk(id, {
    include: [ // Tambahkan include untuk mengambil data Creator dan Editor (User)
      { model: User, as: 'Creator', attributes: ['id', 'username'] }, // Ambil ID dan username saja
      { model: User, as: 'Editor', attributes: ['id', 'username'] }   // Ambil ID dan username saja
    ]
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find Category with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Category with id=" + id
      });
    });
};

// Update a Category by the id in the request
exports.update = (req, res) => {
  // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  const id = req.params.id;
  const updateData = { ...req.body };
  updateData.updatedBy = req.userId; // Set updatedBy dengan ID pengguna yang sedang login

  Category.update(updateData, {
    where: { categoryId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Category was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update Category with id=${id}. Maybe Category was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating Category with id=" + id
      });
    });
};

// Delete a Category with the specified id in the request
exports.delete = (req, res) => {
  const id = req.params.id;

  Category.destroy({
    where: { categoryId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Category was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Category with id=${id}. Maybe Category was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Category with id=" + id
      });
    });
};

// Delete all Categories from the database
exports.deleteAll = (req, res) => {
  Category.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Categories were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all categories."
      });
    });
};