// erp-backend/controllers/transactionproduct.controller.js
const db = require("../models");
const TransactionProduct = db.TransactionProduct;
const Transaction = db.Transaction; // Required for includes and validation
const Product = db.Product; // Required for includes and validation
const Unit = db.Unit; // Required for includes and validation
const User = db.User; // Required for tracking

// Create and Save a new TransactionProduct (add an item to a transaction)
exports.create = async (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const { transactionId, productId, quantity, price, unitId } = req.body;

    // Basic validation
    if (!transactionId || !productId || quantity === undefined || quantity === null || quantity < 0) {
        return res.status(400).send({
            message: "Transaction ID, Product ID, and Quantity (>= 0) cannot be empty!"
        });
    }

    try {
        // Check if the Transaction and Product exist
        const transactionExists = await Transaction.findByPk(transactionId);
        if (!transactionExists) {
            return res.status(404).send({ message: `Transaction with id=${transactionId} not found.` });
        }
        const productExists = await Product.findByPk(productId);
        if (!productExists) {
            return res.status(404).send({ message: `Product with id=${productId} not found.` });
        }

        // Check if the Unit exists if unitId is provided
        if (unitId) {
            const unitExists = await Unit.findByPk(unitId);
            if (!unitExists) {
                 return res.status(404).send({ message: `Unit with id=${unitId} not found.` });
            }
        }

         // Optional: Check for unique constraint violation before attempting to create
         // if you configured a unique key for transactionId and productId in the model
         const existingEntry = await TransactionProduct.findOne({
             where: { transactionId: transactionId, productId: productId }
              // If unique key includes unitId: where: { transactionId: transactionId, productId: productId, unitId: unitId || null }
         });

        if (existingEntry) {
            return res.status(400).send({ message: `Product with id=${productId} already exists in transaction with id=${transactionId}. Consider updating the existing entry instead.` });
        }


        const newEntry = {
            transactionId: transactionId,
            productId: productId,
            quantity: quantity,
            price: price || null, // Set to null if not provided
            unitId: unitId || null, // Set to null if not provided
            createdBy: req.userId,
            updatedBy: req.userId
        };

        const data = await TransactionProduct.create(newEntry);

        // Fetch the newly created entry with relations for response
        const createdEntry = await TransactionProduct.findByPk(data.transactionProductId, {
             include: [
                { model: Transaction, as: 'Transaction', attributes: ['transactionId', 'transactionType', 'transactionDate'] },
                { model: Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'] },
                { model: Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] }
             ]
        });

        res.status(201).send(createdEntry);

    } catch (err) {
        console.error("Error creating TransactionProduct:", err);
        res.status(500).send({
            message:
                err.message || "Some error occurred while creating the TransactionProduct."
        });
    }
};

// Retrieve all TransactionProduct entries (or filter by transactionId)
// This endpoint is likely used to get all items for a specific transaction.
exports.findAllForTransaction = async (req, res) => {
    const transactionId = req.params.transactionId; // Get transactionId from route params

    if (!transactionId) {
         return res.status(400).send({ message: "Transaction ID is required to list transaction products." });
    }

    try {
        // Optional: Check if the transaction exists first
         const transactionExists = await Transaction.findByPk(transactionId);
         if (!transactionExists) {
            return res.status(404).send({ message: `Transaction with id=${transactionId} not found.` });
        }


        const data = await TransactionProduct.findAll({
            where: { transactionId: transactionId },
            include: [
                { model: Transaction, as: 'Transaction', attributes: ['transactionId', 'transactionType', 'transactionDate'] },
                { model: Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'] },
                { model: Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] }
            ],
            order: [['transactionProductId', 'ASC']] // Or order by productId, etc.
        });

        res.send(data);

    } catch (err) {
        console.error("Error retrieving TransactionProducts for transaction:", err);
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving TransactionProducts."
        });
    }
};

// Find a single TransactionProduct entry by transactionProductId
exports.findOne = async (req, res) => {
    const id = req.params.id; // This is the transactionProductId

    try {
        const data = await TransactionProduct.findByPk(id, {
            include: [
                 { model: Transaction, as: 'Transaction', attributes: ['transactionId', 'transactionType', 'storeId', 'counterpartyId', 'counterpartyType', 'transactionDate'] },
                { model: Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'] },
                { model: Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] }
            ]
        });

        if (!data) {
            return res.status(404).send({
                message: `Cannot find TransactionProduct with id=${id}.`
            });
        }

        res.send(data);

    } catch (err) {
        console.error("Error retrieving TransactionProduct:", err);
        res.status(500).send({
            message: "Error retrieving TransactionProduct with id=" + id
        });
    }
};

// Update a TransactionProduct quantity/price/unit by transactionProductId
exports.update = async (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const id = req.params.id; // This is the transactionProductId
    const updateData = { ...req.body }; // Copy body data
    updateData.updatedBy = req.userId; // Set updatedBy

    // Prevent changing transactionId or productId via update
    if (updateData.transactionId !== undefined) delete updateData.transactionId;
    if (updateData.productId !== undefined) delete updateData.productId;

     // Validate unitId if provided in update data
    if (updateData.unitId !== undefined && updateData.unitId !== null) {
         const unitExists = await Unit.findByPk(updateData.unitId);
         if (!unitExists) {
              return res.status(404).send({ message: `Unit with id=${updateData.unitId} not found.` });
         }
    }


    try {
        const num = await TransactionProduct.update(
            updateData, // Update quantity, price, unitId, updatedBy
            { where: { transactionProductId: id } }
        );

        if (num == 1) {
            // Fetch the updated entry with relations for response
            const updatedEntry = await TransactionProduct.findByPk(id, {
                 include: [
                    { model: Transaction, as: 'Transaction', attributes: ['transactionId', 'transactionType', 'transactionDate'] },
                    { model: Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'] },
                    { model: Unit, as: 'TransactionUnit', attributes: ['unitId', 'unitName'] },
                    { model: User, as: 'Creator', attributes: ['id', 'username'] },
                    { model: User, as: 'Editor', attributes: ['id', 'username'] }
                 ]
            });
            res.send(updatedEntry); // Return the updated object

        } else {
            res.status(404).send({ // Use 404 if the item was not found
                message: `Cannot update TransactionProduct with id=${id}. Maybe it was not found or req.body is empty!`
            });
        }
    } catch (err) {
        console.error("Error updating TransactionProduct:", err);
        res.status(500).send({
            message: "Error updating TransactionProduct with id=" + id
        });
    }
};

// Delete a TransactionProduct entry by transactionProductId
exports.delete = async (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const id = req.params.id; // This is the transactionProductId

    try {
        const num = await TransactionProduct.destroy({
            where: { transactionProductId: id }
        });

        if (num == 1) {
            res.send({
                message: "TransactionProduct was deleted successfully!"
            });
        } else {
            res.status(404).send({ // Use 404 if the item was not found
                message: `Cannot delete TransactionProduct with id=${id}. Maybe it was not found!`
            });
        }
    } catch (err) {
        console.error("Error deleting TransactionProduct:", err);
        res.status(500).send({
            message: "Could not delete TransactionProduct with id=" + id
        });
    }
};

// Optional: Delete all TransactionProduct entries for a specific transaction
exports.deleteAllForTransaction = async (req, res) => {
     if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const transactionId = req.params.transactionId;

     if (!transactionId) {
         return res.status(400).send({ message: "Transaction ID is required to delete transaction products." });
    }

    try {
        // Optional: Check if the transaction exists first
         const transactionExists = await Transaction.findByPk(transactionId);
         if (!transactionExists) {
            return res.status(404).send({ message: `Transaction with id=${transactionId} not found.` });
        }

        const nums = await TransactionProduct.destroy({
            where: { transactionId: transactionId },
            truncate: false // Set to true if you want to reset auto-increment for these items (unlikely needed)
        });

        res.send({ message: `${nums} TransactionProduct entries for transaction ${transactionId} were deleted successfully!` });

    } catch (err) {
        console.error("Error deleting TransactionProducts for transaction:", err);
        res.status(500).send({
            message: err.message || `Some error occurred while removing all TransactionProduct entries for transaction ${transactionId}.`
        });
    }
};