// erp-backend/controllers/product.controller.js
const db = require("../models");
const Product = db.Product;
const User = db.User;
const Category = db.Category;
const Unit = db.Unit; // Import Unit model
const ProductUnit = db.ProductUnit; // Import ProductUnit model


const paginateAndSearch = require('../utils/paginationAndSearch');

// Create and Save a new Product
exports.create = (req, res) => {
  // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  if (!req.body.productName) {
    res.status(400).send({
      message: "Product name can not be empty!"
    });
    return;
  }

  // Ambil categoryIds dan baseUnitId dari body request
  const { productName, categoryIds, baseUnitId } = req.body;
  const product = {
    productName: productName,
    baseUnitId: baseUnitId, // Set baseUnitId
    createdBy: req.userId,
    updatedBy: req.userId
  };

  Product.create(product)
    .then(data => {
      // Jika categoryIds ada, hubungkan produk dengan kategori-kategori tersebut
      if (categoryIds && Array.isArray(categoryIds) && categoryIds.length > 0) {
        Category.findAll({
          where: {
            categoryId: categoryIds
          }
        }).then(categories => {
          data.setCategories(categories)
            .then(() => {
               // Respon setelah kategori terhubung
               // Anda mungkin ingin mengembalikan data produk dengan relasi yang di-include di sini,
               // tapi untuk sederhana, kembalikan data produk yang baru dibuat.
               // Detail dengan relasi akan diambil saat findOne/fetch detail.
              res.status(201).send(data);
            })
            .catch(err => {
               console.error("Error associating categories to product:", err);
               res.status(500).send({
                 message: err.message || "Product created, but failed to associate categories."
               });
            });
        }).catch(err => {
           console.error("Error finding categories for association:", err);
           res.status(500).send({
             message: err.message || "Product created, but failed to find specified categories."
           });
        });
      } else {
         res.status(201).send(data); // Kirim data produk jika tidak ada kategori atau konversi yang dipilih saat pembuatan
      }
      // Logika untuk menambahkan ProductUnit awal saat produk dibuat (Opsional)
      // Jika Anda mengizinkan penambahan konversi awal saat pembuatan produk,
      // Anda akan memproses req.body yang berisi data konversi di sini
      // dan membuat entri di tabel ProductUnits
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Product."
      });
    });
};

// Retrieve all Products with pagination and search
exports.findAll = async (req, res) => {
  const searchableFields = ['productName'];
  const options = {
    order: [['productId', 'ASC']],
    // Tambahkan include BaseUnit jika ingin menampilkan unit dasar di daftar produk
    include: [
      // HAPUS INCLUDE BaseUnit, TINGGALKAN Category
      { 
        model: db.Category, 
        through: { attributes: [] }, 
        attributes: ['categoryName'] 
      },
      { 
        model: db.Unit, 
        as: 'BaseUnit',
        attributes: ['unitId', 'unitName']
      }
    ]
  };

  try {
    const result = await paginateAndSearch(Product, req.query, searchableFields, options);
    res.send({
      items: result.items,
      totalItems: result.totalItems,
      currentPage: result.currentPage,
      totalPages: result.totalPages
    });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving products."
    });
  }
};

// Find a single Product with an id
// Tambahkan include Category, BaseUnit, dan ProductUnit (konversi unit)
exports.findOne = (req, res) => {
  const id = req.params.id;

  Product.findByPk(id, {
    include: [ // Tambahkan include untuk mengambil data relasi
      { model: User, as: 'Creator', attributes: ['id', 'username'] },
      { model: User, as: 'Editor', attributes: ['id', 'username'] },
      { model: Category, through: { attributes: [] } }, // Include Category
      { model: db.Unit, as: 'BaseUnit', attributes: ['unitId', 'unitName'] }, // Include BaseUnit
      { // Include ProductUnit and the related Unit details
        model: db.ProductUnit,
         as: 'ProductUnits', // Nama alias dari relasi hasMany di model Product
        include: [
             { model: db.Unit, as: 'ConvertedUnit', attributes: ['unitId', 'unitName'] },
             { model: User, as: 'Creator', attributes: ['id', 'username'] }, // Optional: Include creator/editor for conversion
             { model: User, as: 'Editor', attributes: ['id', 'username'] }
        ]
      }
    ]
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find Product with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Product with id=" + id
      });
    });
};

// Update a Product by the id in the request
// Modifikasi untuk menangani update baseUnitId dan Category juga
exports.update = (req, res) => {
  // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  const id = req.params.id;
  // Ambil updateData, categoryIds, dan baseUnitId dari body request
  const { categoryIds, baseUnitId, ...updateData } = req.body;
  updateData.updatedBy = req.userId; // Set updatedBy dengan ID pengguna yang sedang login

  Product.findByPk(id) // Cari produk terlebih dahulu
    .then(product => {
      if (!product) {
        return res.status(404).send({
          message: `Cannot update Product with id=${id}. Product not found!`
        });
      }

      // Update data produk (termasuk baseUnitId)
      product.update({...updateData, baseUnitId: baseUnitId}) // Pastikan baseUnitId di-update
        .then(() => {
          // Jika categoryIds ada, update asosiasi kategori
          if (categoryIds !== undefined) { // Cek apakah categoryIds dikirimkan (bisa array kosong)
             Category.findAll({
                where: {
                  categoryId: categoryIds
                }
             })
             .then(categories => {
                 product.setCategories(categories) // Mengganti asosiasi yang sudah ada dengan yang baru
                    .then(() => {
                       // Cek apakah update konversi unit juga perlu diproses di sini
                       // Namun, lebih baik CRUD ProductUnit dilakukan melalui endpoint terpisah (/api/product-units)
                       // Jadi, kita hanya mengirim pesan sukses untuk update produk dan kategori
                       res.send({
                          message: "Product and categories were updated successfully."
                        });
                    })
                    .catch(err => {
                       console.error("Error setting categories for product:", err);
                       res.status(500).send({
                         message: err.message || "Product updated, but failed to update categories."
                       });
                    });
             })
             .catch(err => {
                console.error("Error finding categories for update:", err);
                res.status(500).send({
                  message: err.message || "Product updated, but failed to find specified categories."
                });
             });
          } else {
            // Jika categoryIds tidak dikirim, hanya update data produk (termasuk baseUnitId jika ada di body)
            res.send({
              message: "Product was updated successfully."
            });
          }
          // Jika update data ProductUnit juga dikirim di body,
          // Anda akan memprosesnya di sini, mungkin dengan menggunakansetProductUnits atau create/update/delete manual
          // Tapi lagi, lebih baik CRUD ProductUnit dilakukan via endpoint terpisah.

        })
        .catch(err => {
          // Handle error saat update data produk
           res.status(500).send({
             message: err.message || "Error updating Product data with id=" + id
           });
        });
    })
    .catch(err => {
      // Handle error saat mencari produk
      res.status(500).send({
        message: "Error finding Product with id=" + id
      });
    });
};


// Delete a Product with the specified id in the request (Tidak perlu diubah untuk relasi many-to-many)
exports.delete = (req, res) => {
  const id = req.params.id;

  Product.destroy({
    where: { productId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Product was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Product with id=${id}. Maybe Product was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Product with id=" + id
      });
    });
};

// Delete all Products from the database (Tidak perlu diubah untuk relasi many-to-many)
exports.deleteAll = (req, res) => {
  Product.destroy({
    where: {},
    truncate: false // Set truncate: true jika ingin mereset auto-increment ID
  })
    .then(nums => {
      res.send({ message: `${nums} Products were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all products."
      });
    });
};