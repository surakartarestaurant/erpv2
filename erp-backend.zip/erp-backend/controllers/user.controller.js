// controllers/user.controller.js
const db = require("../models");
const User = db.User;
const bcrypt = require("bcrypt");

const paginateAndSearch = require('../utils/paginationAndSearch');

// Create and Save a new User
exports.create = (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  if (!req.body.username || !req.body.email || !req.body.password) {
    return res.status(400).send({ message: "Username, email, and password cannot be empty!" });
  }

  const hashedPassword = bcrypt.hashSync(req.body.password, 8);

  const user = {
    username: req.body.username,
    email: req.body.email,
    password: hashedPassword,
    role: req.body.role || 'Guest', // Tambahkan role
    createdBy: req.userId,
    updatedBy: req.userId
  };

  User.create(user)
    .then(data => {
      const { password, ...userData } = data.get();
      res.status(201).send(userData);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the User."
      });
    });
};

// Retrieve all Users with pagination and search
exports.findAll = async (req, res) => {
  const searchableFields = ['username', 'email'];
  const options = {
    attributes: { exclude: ['password'] },
    order: [['id', 'ASC']]
  };

  try {
    const result = await paginateAndSearch(User, req.query, searchableFields, options);
    res.send({
      items: result.items,
      totalItems: result.totalItems,
      currentPage: result.currentPage,
      totalPages: result.totalPages
    });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving users."
    });
  }
};

// Find a single User with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  User.findByPk(id, {
    attributes: { exclude: ['password'] },
    include: [
      { model: User, as: 'Creator', attributes: ['id', 'username'] },
      { model: User, as: 'Editor', attributes: ['id', 'username'] }
    ]
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find User with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving User with id=" + id
      });
    });
};

// Update a User by the id in the request
exports.update = (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  const id = req.params.id;
  const updateData = { ...req.body };

  if (updateData.password) {
    updateData.password = bcrypt.hashSync(updateData.password, 8);
  }

  updateData.updatedBy = req.userId;

  User.update(updateData, {
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "User was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update User with id=${id}. Maybe User was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating User with id=" + id
      });
    });
};

// Delete a User with the specified id
exports.delete = (req, res) => {
  const id = req.params.id;

  User.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "User was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete User with id=${id}. Maybe User was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete User with id=" + id
      });
    });
};

// Delete all Users
exports.deleteAll = (req, res) => {
  User.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Users were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while removing all users."
      });
    });
};