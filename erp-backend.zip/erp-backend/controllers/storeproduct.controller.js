// erp-backend/controllers/storeproduct.controller.js
const db = require("../models");
const StoreProduct = db.StoreProduct;
const Store = db.Store; // Import Store model to include in queries
const Product = db.Product; // Import Product model to include in queries
const User = db.User; // Import User model for tracking

// You might not need pagination/search for this controller initially,
// as you'll likely fetch by storeId or productId.
// If needed, you can adapt paginateAndSearch, but it might require
// modifications to handle filtering by foreign keys.

// --- Helper function to get auth header ---
const getAuthHeader = (req) => {
  const token = req.headers["x-access-token"];
  return { headers: { 'x-access-token': token } };
};


// Create and Save a new StoreProduct (Add/Set stock for a product in a store)
exports.create = async (req, res) => {
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  const { storeId, productId, quantity } = req.body;

  // Basic validation
  if (!storeId || !productId || quantity === undefined || quantity === null || quantity < 0) {
    res.status(400).send({
      message: "Store ID, Product ID, and Quantity (>= 0) cannot be empty!"
    });
    return;
  }

  try {
    // Optional: Check if the Store and Product exist before creating the association
    const storeExists = await Store.findByPk(storeId);
    const productExists = await Product.findByPk(productId);

    if (!storeExists) {
        return res.status(404).send({ message: `Store with id=${storeId} not found.` });
    }
    if (!productExists) {
        return res.status(404).send({ message: `Product with id=${productId} not found.` });
    }

    // Check if an entry for this store and product already exists
    let existingEntry = await StoreProduct.findOne({
        where: { storeId: storeId, productId: productId }
    });

    if (existingEntry) {
        // If exists, update the quantity
        existingEntry.quantity = quantity;
        existingEntry.updatedBy = req.userId;
        await existingEntry.save(); // Use save() on instance to trigger hooks/updatedAt

        // Fetch the updated entry with relations for response
        const updatedEntry = await StoreProduct.findByPk(existingEntry.storeProductId, {
             include: [
                { model: Store, as: 'Store', attributes: ['storeId', 'storeName'] },
                { model: Product, as: 'Product', attributes: ['productId', 'productName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] }
             ]
        });

        res.status(200).send(updatedEntry); // Use 200 for update
    } else {
        // If not exists, create a new entry
        const newEntry = {
            storeId: storeId,
            productId: productId,
            quantity: quantity,
            createdBy: req.userId,
            updatedBy: req.userId
        };

        const data = await StoreProduct.create(newEntry);

         // Fetch the newly created entry with relations for response
        const createdEntry = await StoreProduct.findByPk(data.storeProductId, {
             include: [
                { model: Store, as: 'Store', attributes: ['storeId', 'storeName'] },
                { model: Product, as: 'Product', attributes: ['productId', 'productName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] }
             ]
        });


        res.status(201).send(createdEntry); // Use 201 for creation
    }

  } catch (err) {
    console.error("Error creating/updating StoreProduct:", err);
    res.status(500).send({
      message:
        err.message || "Some error occurred while creating/updating the StoreProduct."
    });
  }
};


// Retrieve all StoreProduct entries (or filter by storeId/productId)
// This endpoint could list ALL entries, or be adapted to filter.
// Let's create one that can be filtered by storeId OR productId from query params.
exports.findAll = async (req, res) => {
  const { storeId, productId } = req.query; // Get storeId or productId from query params

  let whereCondition = {};
  if (storeId) {
      whereCondition.storeId = storeId;
  }
  if (productId) {
      whereCondition.productId = productId;
  }
    // If both are provided, it will act like findOne but return in an array

  try {
    const data = await StoreProduct.findAll({
      where: whereCondition,
      include: [
        { model: Store, as: 'Store', attributes: ['storeId', 'storeName'] },
        { model: Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'],
            include: [{ // Include BaseUnit of the Product
                model: db.Unit,
                as: 'BaseUnit',
                attributes: ['unitName']
            }]
         },
        { model: User, as: 'Creator', attributes: ['id', 'username'] },
        { model: User, as: 'Editor', attributes: ['id', 'username'] }
      ],
      order: [['storeProductId', 'ASC']] // Or order by storeId, productId
    });

    res.send(data);
  } catch (err) {
    console.error("Error retrieving StoreProducts:", err);
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving StoreProducts."
    });
  }
};


// Find a single StoreProduct entry by storeProductId
exports.findOne = (req, res) => {
  const id = req.params.id; // This is the storeProductId

  StoreProduct.findByPk(id, {
     include: [
        { model: Store, as: 'Store', attributes: ['storeId', 'storeName'] },
        { model: Product, as: 'Product', attributes: ['productId', 'productName', 'baseUnitId'],
             include: [{ // Include BaseUnit of the Product
                model: db.Unit,
                as: 'BaseUnit',
                attributes: ['unitName']
            }]
        },
        { model: User, as: 'Creator', attributes: ['id', 'username'] },
        { model: User, as: 'Editor', attributes: ['id', 'username'] }
     ]
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find StoreProduct with id=${id}.`
        });
      }
    })
    .catch(err => {
      console.error("Error retrieving StoreProduct:", err);
      res.status(500).send({
        message: "Error retrieving StoreProduct with id=" + id
      });
    });
};


// Update a StoreProduct quantity by storeProductId
exports.update = async (req, res) => {
   if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
   }

  const id = req.params.id; // This is the storeProductId
  const { quantity } = req.body; // Only allow quantity update

  // Basic validation for quantity
  if (quantity === undefined || quantity === null || quantity < 0) {
       return res.status(400).send({ message: "Quantity (>= 0) cannot be empty for update!" });
  }

  try {
    const num = await StoreProduct.update(
      { quantity: quantity, updatedBy: req.userId }, // Update quantity and updatedBy
      { where: { storeProductId: id } }
    );

    if (num == 1) {
        // Fetch the updated entry with relations for response
        const updatedEntry = await StoreProduct.findByPk(id, {
             include: [
                { model: Store, as: 'Store', attributes: ['storeId', 'storeName'] },
                { model: Product, as: 'Product', attributes: ['productId', 'productName'] },
                { model: User, as: 'Creator', attributes: ['id', 'username'] },
                { model: User, as: 'Editor', attributes: ['id', 'username'] }
             ]
        });
        res.send(updatedEntry); // Return the updated object
    } else {
      res.status(404).send({ // Use 404 if the item was not found
        message: `Cannot update StoreProduct with id=${id}. Maybe it was not found.`
      });
    }
  } catch (err) {
    console.error("Error updating StoreProduct:", err);
    res.status(500).send({
      message: "Error updating StoreProduct with id=" + id
    });
  }
};


// Delete a StoreProduct entry by storeProductId
exports.delete = (req, res) => {
   if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
   }

  const id = req.params.id; // This is the storeProductId

  StoreProduct.destroy({
    where: { storeProductId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "StoreProduct was deleted successfully!"
        });
      } else {
        res.status(404).send({ // Use 404 if the item was not found
          message: `Cannot delete StoreProduct with id=${id}. Maybe it was not found!`
        });
      }
    })
    .catch(err => {
      console.error("Error deleting StoreProduct:", err);
      res.status(500).send({
        message: "Could not delete StoreProduct with id=" + id
      });
    });
};

// Optional: Delete all StoreProduct entries for a specific store
exports.deleteAllForStore = (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const storeId = req.params.storeId;

    StoreProduct.destroy({
        where: { storeId: storeId },
        truncate: false
    })
    .then(nums => {
        res.send({ message: `${nums} StoreProduct entries for store ${storeId} were deleted successfully!` });
    })
    .catch(err => {
        console.error("Error deleting StoreProduct for store:", err);
        res.status(500).send({
            message: err.message || `Some error occurred while removing all StoreProduct entries for store ${storeId}.`
        });
    });
};

// Optional: Delete all StoreProduct entries for a specific product
exports.deleteAllForProduct = (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const productId = req.params.productId;

    StoreProduct.destroy({
        where: { productId: productId },
        truncate: false
    })
    .then(nums => {
        res.send({ message: `${nums} StoreProduct entries for product ${productId} were deleted successfully!` });
    })
    .catch(err => {
        console.error("Error deleting StoreProduct for product:", err);
        res.status(500).send({
            message: err.message || `Some error occurred while removing all StoreProduct entries for product ${productId}.`
        });
    });
};