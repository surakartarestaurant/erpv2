// controllers/customer.controller.js
const db = require("../models");
const Customer = db.Customer;
const User = db.User;

const paginateAndSearch = require('../utils/paginationAndSearch');

exports.create = (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found." });
  }

  if (!req.body.customerName) {
    return res.status(400).send({ message: "Customer name cannot be empty!" });
  }

  const customer = {
    customerName: req.body.customerName,
    createdBy: req.userId,
    updatedBy: req.userId
  };

  Customer.create(customer)
    .then(data => res.status(201).send(data))
    .catch(err => res.status(500).send({ message: err.message || "Some error occurred while creating the Customer." }));
};

exports.findAll = async (req, res) => {
  const searchableFields = ['customerName'];
  const options = { order: [['customerId', 'ASC']] };

  try {
    const result = await paginateAndSearch(Customer, req.query, searchableFields, options);
    res.send({
      items: result.items,
      totalItems: result.totalItems,
      currentPage: result.currentPage,
      totalPages: result.totalPages
    });
  } catch (err) {
    res.status(500).send({ message: err.message || "Some error occurred while retrieving customers." });
  }
};

exports.findOne = (req, res) => {
  const id = req.params.id;

  Customer.findByPk(id, {
    include: [
      { model: User, as: 'Creator', attributes: ['id', 'username'] },
      { model: User, as: 'Editor', attributes: ['id', 'username'] }
    ]
  })
    .then(data => {
      if (data) res.send(data);
      else res.status(404).send({ message: `Cannot find Customer with id=${id}.` });
    })
    .catch(err => res.status(500).send({ message: "Error retrieving Customer with id=" + id }));
};

exports.update = (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found." });
  }

  const id = req.params.id;
  const updateData = { ...req.body, updatedBy: req.userId };

  Customer.update(updateData, { where: { customerId: id } })
    .then(num => {
      if (num == 1) res.send({ message: "Customer was updated successfully." });
      else res.send({ message: `Cannot update Customer with id=${id}. Maybe not found.` });
    })
    .catch(err => res.status(500).send({ message: "Error updating Customer with id=" + id }));
};

exports.delete = (req, res) => {
  const id = req.params.id;

  Customer.destroy({ where: { customerId: id } })
    .then(num => {
      if (num == 1) res.send({ message: "Customer was deleted successfully!" });
      else res.send({ message: `Cannot delete Customer with id=${id}. Maybe not found.` });
    })
    .catch(err => res.status(500).send({ message: "Could not delete Customer with id=" + id }));
};

exports.deleteAll = (req, res) => {
  Customer.destroy({ where: {}, truncate: false })
    .then(nums => res.send({ message: `${nums} Customers were deleted successfully!` }))
    .catch(err => res.status(500).send({ message: err.message || "Some error occurred while removing all customers." }));
};