// controllers/productunit.controller.js
const db = require("../models");
const ProductUnit = db.ProductUnit;
const Product = db.Product;
const Unit = db.Unit;
const User = db.User;

// Create and Save a new ProductUnit (add a unit for a product)
exports.create = (req, res) => {
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  const { productId, unitId, conversionFactor } = req.body;

  if (!productId || !unitId || conversionFactor === undefined || conversionFactor === null) {
    res.status(400).send({
      message: "productId, unitId, and conversionFactor cannot be empty!"
    });
    return;
  }

  // Optional: Check if the product and unit exist
  // Optional: Check if the unitId is not the base unit of the product

  const productUnit = {
    productId: productId,
    unitId: unitId,
    conversionFactor: conversionFactor,
    createdBy: req.userId,
    updatedBy: req.userId
  };

  ProductUnit.create(productUnit)
    .then(data => {
      res.status(201).send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the ProductUnit."
      });
    });
};

// Retrieve all ProductUnits for a specific product
exports.findAllForProduct = async (req, res) => {
  const productId = req.params.productId; // Ambil productId dari parameter route

  // Optional: Pastikan user memiliki akses ke produk ini jika diperlukan otorisasi per produk
   if (!req.userId) {
      return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
   }

  try {
    const data = await ProductUnit.findAll({
      where: { productId: productId },
      include: [
        { model: db.Unit, as: 'ConvertedUnit', attributes: ['unitId', 'unitName'] },
        { model: User, as: 'Creator', attributes: ['id', 'username'] },
        { model: User, as: 'Editor', attributes: ['id', 'username'] }
      ],
       order: [['productUnitId', 'ASC']] // Sesuaikan urutan jika perlu
    });
    res.send(data);
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving ProductUnit."
    });
  }
};


// Find a single ProductUnit by id
exports.findOne = (req, res) => {
  const id = req.params.id; // Ini adalah productUnitId

  ProductUnit.findByPk(id, {
     include: [
        { model: db.Product, attributes: ['productId', 'productName', 'baseUnitId'] },
        { model: db.Unit, as: 'ConvertedUnit', attributes: ['unitId', 'unitName'] },
        { model: User, as: 'Creator', attributes: ['id', 'username'] },
        { model: User, as: 'Editor', attributes: ['id', 'username'] }
     ]
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find ProductUnit with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving ProductUnit with id=" + id
      });
    });
};


// Update a ProductUnit by the id in the request
exports.update = (req, res) => {
   if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
   }

  const id = req.params.id; // Ini adalah productUnitId
  const updateData = { ...req.body };
  updateData.updatedBy = req.userId; // Set updatedBy dengan ID pengguna yang sedang login

  // Pastikan productId dan unitId tidak diubah jika sudah ada
  if (updateData.productId !== undefined) delete updateData.productId;
  if (updateData.unitId !== undefined) delete updateData.unitId;

  ProductUnit.update(updateData, {
    where: { productUnitId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "ProductUnit was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update ProductUnit with id=${id}. Maybe it was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating ProductUnit with id=" + id
      });
    });
};

// Delete a ProductUnit with the specified id in the request
exports.delete = (req, res) => {
   if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
   }

  const id = req.params.id; // Ini adalah productUnitId

  ProductUnit.destroy({
    where: { productUnitId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "ProductUnit was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete ProductUnit with id=${id}. Maybe it was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete ProductUnit with id=" + id
      });
    });
};

// Delete all ProductUnit for a specific product (Optional endpoint)
exports.deleteAllForProduct = (req, res) => {
    if (!req.userId) {
        return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    const productId = req.params.productId;

    ProductUnit.destroy({
        where: { productId: productId },
        truncate: false // Set to true if you want to reset auto-increment for this product (unlikely needed)
    })
    .then(nums => {
        res.send({ message: `${nums} ProductUnit for product ${productId} were deleted successfully!` });
    })
    .catch(err => {
        res.status(500).send({
            message: err.message || `Some error occurred while removing all ProductUnit for product ${productId}.`
        });
    });
};