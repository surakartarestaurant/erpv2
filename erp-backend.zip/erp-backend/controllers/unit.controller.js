// controllers/unit.controller.js
const db = require("../models");
const Unit = db.Unit;
const User = db.User; // Import model User untuk include

const paginateAndSearch = require('../utils/paginationAndSearch');

// Create and Save a new Unit
exports.create = (req, res) => {
  // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  if (!req.body.unitName) {
    res.status(400).send({
      message: "Unit name can not be empty!"
    });
    return;
  }

  const unit = {
    unitName: req.body.unitName,
    createdBy: req.userId, // Set createdBy dengan ID pengguna yang sedang login
    updatedBy: req.userId  // Set updatedBy dengan ID pengguna yang sedang login saat pertama dibuat
  };

  Unit.create(unit)
    .then(data => {
      res.status(201).send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Unit."
      });
    });
};

// Retrieve all Units with pagination and search
exports.findAll = async (req, res) => {
  const searchableFields = ['unitName'];
  const options = {
    order: [['unitId', 'ASC']]
    // Tidak perlu include User di sini jika tidak ditampilkan di daftar
  };

  try {
    const result = await paginateAndSearch(Unit, req.query, searchableFields, options);
    res.send({
      items: result.items,
      totalItems: result.totalItems,
      currentPage: result.currentPage,
      totalPages: result.totalPages
    });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving units."
    });
  }
};

// Find a single Unit with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  Unit.findByPk(id, {
    include: [ // Tambahkan include untuk mengambil data Creator dan Editor (User)
      { model: User, as: 'Creator', attributes: ['id', 'username'] }, // Ambil ID dan username saja
      { model: User, as: 'Editor', attributes: ['id', 'username'] }   // Ambil ID dan username saja
    ]
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find Unit with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Unit with id=" + id
      });
    });
};

// Update a Unit by the id in the request
exports.update = (req, res) => {
   // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  const id = req.params.id;
  const updateData = { ...req.body };
  updateData.updatedBy = req.userId; // Set updatedBy dengan ID pengguna yang sedang login

  Unit.update(updateData, {
    where: { unitId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Unit was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update Unit with id=${id}. Maybe Unit was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating Unit with id=" + id
      });
    });
};

// Delete a Unit with the specified id in the request
exports.delete = (req, res) => {
  const id = req.params.id;

  Unit.destroy({
    where: { unitId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Unit was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Unit with id=${id}. Maybe Unit was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Unit with id=" + id
      });
    });
};

// Delete all Units from the database
exports.deleteAll = (req, res) => {
  Unit.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Units were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all units."
      });
    });
};