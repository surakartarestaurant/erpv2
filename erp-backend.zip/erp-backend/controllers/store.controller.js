// erp-backend/controllers/store.controller.js
const db = require("../models");
const Store = db.Store;
const User = db.User; // Pastikan User model diimpor
const Product = db.Product; // Pastikan Product model diimpor
const StoreProduct = db.StoreProduct; // Pastikan StoreProduct model diimpor
const Unit = db.Unit; // Pastikan Unit model diimpor jika perlu menampilkan Base Unit Produk


const paginateAndSearch = require('../utils/paginationAndSearch'); //

// Create and Save a new Store
exports.create = (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found in request." }); // [cite: 186]
  }

  if (!req.body.storeName) {
    return res.status(400).send({
      message: "Store name cannot be empty!" // [cite: 187]
    });
  }

  const store = {
    storeName: req.body.storeName,
    createdBy: req.userId, // [cite: 188]
    updatedBy: req.userId // [cite: 188]
  };
  Store.create(store) // [cite: 188]
    .then(data => {
      res.status(201).send(data); // [cite: 188]
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the Store." // [cite: 189]
      });
    });
};

// Retrieve all Stores with pagination and search
exports.findAll = async (req, res) => {
  const searchableFields = ['storeName']; // [cite: 190]
  const options = {
    order: [['storeId', 'ASC']] // [cite: 191]
  };
  try {
    const result = await paginateAndSearch(Store, req.query, searchableFields, options); // [cite: 192]
    res.send({
      items: result.items,
      totalItems: result.totalItems,
      currentPage: result.currentPage,
      totalPages: result.totalPages
    }); // [cite: 192]
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving stores." // [cite: 193, 194]
    });
  }
};


// Find a single Store with an id - MODIFIKASI LENGKAP DI FUNGSI INI
exports.findOne = (req, res) => {
  const id = req.params.id; // [cite: 195]
  Store.findByPk(id, {
    include: [
      { model: User, as: 'Creator', attributes: ['id', 'username'] }, // [cite: 195]
      { model: User, as: 'Editor', attributes: ['id', 'username'] }, // [cite: 195]
      // --- TAMBAHKAN INCLUDE INI UNTUK MENGAMBIL DATA INVENTORY ---
      {
          model: StoreProduct,
          as: 'StoreProducts', // Menggunakan alias yang didefinisikan di store.model.js
          include: [
              {
                  model: Product,
                  as: 'Product', // Menggunakan alias yang didefinisikan di storeproduct.model.js
                  attributes: ['productId', 'productName', 'baseUnitId'],
                  include: [{ // Include BaseUnit of the Product
                       model: Unit, // Menggunakan Unit model
                       as: 'BaseUnit',
                       attributes: ['unitName']
                  }]
              },
              { model: User, as: 'Creator', attributes: ['id', 'username'] }, // Opsional: Pelacakan di entry StoreProduct
              { model: User, as: 'Editor', attributes: ['id', 'username'] }    // Opsional: Pelacakan di entry StoreProduct
          ]
      }
      // ----------------------------------------------------------
    ]
  })
    .then(data => {
      if (data) {
        res.send(data); // [cite: 196]
      } else {
        res.status(404).send({
          message: `Cannot find Store with id=${id}.` // [cite: 196]
        });
      }
    })
    .catch(err => {
      console.error("Error retrieving Store with inventory:", err); // Log error lebih detail
      res.status(500).send({
        message: "Error retrieving Store with id=" + id // [cite: 197]
      });
    });
};

// Update a Store by the id
exports.update = (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found in request." }); // [cite: 198]
  }

  const id = req.params.id; // [cite: 199]
  const updateData = { ...req.body }; // [cite: 199]
  updateData.updatedBy = req.userId; // [cite: 199]

  Store.update(updateData, { // [cite: 199]
    where: { storeId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Store was updated successfully." // [cite: 200]
        });
      } else {
        res.send({
          message: `Cannot update Store with id=${id}. Maybe Store was not found or req.body is empty!` // [cite: 200]
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating Store with id=" + id // [cite: 201]
      });
    });
};

// Delete a Store
exports.delete = (req, res) => {
  const id = req.params.id; // [cite: 202]
  Store.destroy({
    where: { storeId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Store was deleted successfully!" // [cite: 203]
        });
      } else {
        res.send({
          message: `Cannot delete Store with id=${id}. Maybe Store was not found!` // [cite: 203]
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Store with id=" + id // [cite: 204]
      });
    });
};

// Delete all Stores
exports.deleteAll = (req, res) => {
  Store.destroy({
    where: {},
    truncate: false // [cite: 205]
  })
    .then(nums => {
      res.send({ message: `${nums} Stores were deleted successfully!` }); // [cite: 205]
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all stores." // [cite: 205]
      });
    });
};