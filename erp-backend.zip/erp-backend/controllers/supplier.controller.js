// erp-backend/controllers/supplier.controller.js
const db = require("../models");
const Supplier = db.Supplier;
const User = db.User; // Import model User untuk include

const paginateAndSearch = require('../utils/paginationAndSearch');

// Create and Save a new Supplier
exports.create = (req, res) => {
  // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  if (!req.body.supplierName) {
    res.status(400).send({
      message: "Supplier name can not be empty!"
    });
    return;
  }

  const supplier = {
    supplierName: req.body.supplierName,
    supplierTelephone: req.body.supplierTelephone,
    createdBy: req.userId, // Set createdBy dengan ID pengguna yang sedang login
    updatedBy: req.userId  // Set updatedBy dengan ID pengguna yang sedang login saat pertama dibuat
  };

  Supplier.create(supplier)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Supplier."
      });
    });
};

// Retrieve all Suppliers with pagination and search (Tidak perlu menampilkan createdBy/updatedBy di sini, fokus pada detail)
exports.findAll = async (req, res) => {
  const searchableFields = ['supplierName', 'supplierTelephone'];
  const options = {
    order: [['supplierId', 'ASC']]
    // Tidak perlu include User di sini jika tidak ditampilkan di daftar
  };

  try {
    const result = await paginateAndSearch(Supplier, req.query, searchableFields, options);
     res.send({
      items: result.items,
      totalItems: result.totalItems,
      currentPage: result.currentPage,
      totalPages: result.totalPages
    });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving suppliers."
    });
  }
};

// Find a single Supplier with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  Supplier.findByPk(id, {
     include: [ // Tambahkan include untuk mengambil data Creator dan Editor (User)
      { model: User, as: 'Creator', attributes: ['id', 'username'] }, // Ambil ID dan username saja
      { model: User, as: 'Editor', attributes: ['id', 'username'] }   // Ambil ID dan username saja
    ]
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find Supplier with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Supplier with id=" + id
      });
    });
};

// Update a Supplier by the id in the request
exports.update = (req, res) => {
   // Pastikan user terotentikasi dan req.userId tersedia dari middleware
  if (!req.userId) {
     return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
  }

  const id = req.params.id;
  const updateData = { ...req.body };
  updateData.updatedBy = req.userId; // Set updatedBy dengan ID pengguna yang sedang login


  Supplier.update(updateData, {
    where: { supplierId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Supplier was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update Supplier with id=${id}. Maybe Supplier was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating Supplier with id=" + id
      });
    });
};

// Delete a Supplier with the specified id in the request (Tidak ada perubahan terkait pelacakan)
exports.delete = (req, res) => {
  const id = req.params.id;

  Supplier.destroy({
    where: { supplierId: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Supplier was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Supplier with id=${id}. Maybe Supplier was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Supplier with id=" + id
      });
    });
};

// Delete all Suppliers from the database (Tidak ada perubahan terkait pelacakan)
exports.deleteAll = (req, res) => {
  Supplier.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Suppliers were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all suppliers."
      });
    });
};