// controllers/productcomponent.controller.js
const db = require("../models");
const ProductComponent = db.ProductComponent;
const Product = db.Product;
const User = db.User;
const formatQuantity = require("../utils/formatQuantity"); // Import fungsi formatQuantity

exports.create = async (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found." });
  }

  const { productId, componentId, quantity } = req.body;

  if (!productId || !componentId || quantity === undefined) {
    return res.status(400).send({ message: "productId, componentId, and quantity are required!" });
  }

  // Cegah komponen sama dengan produk utama
  if (productId === componentId) {
    return res.status(400).send({ message: "Product cannot be its own component!" });
  }

  try {
    const component = await ProductComponent.create({
      productId,
      componentId,
      quantity,
      createdBy: req.userId,
      updatedBy: req.userId
    });

    // Ambil data komponen lengkap dengan relasi
    const newComponent = await ProductComponent.findByPk(component.productComponentId, {
      include: [
        { model: Product, as: 'Component' },
        { model: User, as: 'Creator', attributes: ['id', 'username'] },
        { model: User, as: 'Editor', attributes: ['id', 'username'] }
      ]
    });

    // Format quantity sebelum mengirim response
    newComponent.quantity = formatQuantity(newComponent.quantity);

    res.status(201).send(newComponent);
  } catch (error) {
    res.status(500).send({
      message: error.message || "Failed to create product component"
    });
  }
};

exports.findAllForProduct = async (req, res) => {
  const productId = req.params.productId;

  try {
    const components = await ProductComponent.findAll({
      where: { productId },
      include: [
        {
          model: Product,
          as: 'Component',
          attributes: ['productId', 'productName'],
          include: [
            {
              model: db.Unit,
              as: 'BaseUnit',
              attributes: ['unitId', 'unitName']
            }
          ]
        },
        { model: User, as: 'Creator', attributes: ['id', 'username'] },
        { model: User, as: 'Editor', attributes: ['id', 'username'] }
      ],
      order: [['productComponentId', 'ASC']]
    });

    // Format quantity sebelum mengirim response
    const formattedComponents = components.map(component => {
      component.quantity = formatQuantity(component.quantity);
      return component;
    });

    res.send(formattedComponents);
  } catch (error) {
    res.status(500).send({
      message: error.message || "Failed to retrieve components"
    });
  }
};

exports.update = async (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found." });
  }

  const id = req.params.id;
  const { quantity } = req.body;

  try {
    const component = await ProductComponent.findByPk(id);

    if (!component) {
      return res.status(404).send({ message: "Component not found" });
    }

    // Hanya update quantity dan updatedBy
    await component.update({
      quantity,
      updatedBy: req.userId
    });

    // Ambil data terbaru dengan relasi
    const updatedComponent = await ProductComponent.findByPk(id, {
      include: [
        { model: Product, as: 'Component' },
        { model: User, as: 'Creator', attributes: ['id', 'username'] },
        { model: User, as: 'Editor', attributes: ['id', 'username'] }
      ]
    });

    // Format quantity sebelum mengirim response
    updatedComponent.quantity = formatQuantity(updatedComponent.quantity);

    res.send(updatedComponent);
  } catch (error) {
    res.status(500).send({
      message: error.message || "Failed to update component"
    });
  }
};

exports.delete = async (req, res) => {
  if (!req.userId) {
    return res.status(401).send({ message: "Unauthorized! User ID not found." });
  }

  const id = req.params.id;

  try {
    const component = await ProductComponent.findByPk(id);

    if (!component) {
      return res.status(404).send({ message: "Component not found" });
    }

    await component.destroy();
    res.send({ message: "Component deleted successfully!" });
  } catch (error) {
    res.status(500).send({
      message: error.message || "Failed to delete component"
    });
  }
};