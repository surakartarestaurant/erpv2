// routes/store.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize");
const controller = require("../controllers/store.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  const storeAllowedRoles = ['Super', 'Manager', 'Admin'];
  const storeReadAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational', 'Guest'];

  app.route("/api/stores")
    .post([authJwt.verifyToken, authorize(storeAllowedRoles)], controller.create)
    .get([authJwt.verifyToken, authorize(storeReadAllowedRoles)], controller.findAll)
    .delete([authJwt.verifyToken, authorize(['Super', 'Admin'])], controller.deleteAll);

  app.route("/api/stores/:id")
    .get([authJwt.verifyToken, authorize(storeReadAllowedRoles)], controller.findOne)
    .put([authJwt.verifyToken, authorize(storeAllowedRoles)], controller.update)
    .delete([authJwt.verifyToken, authorize(storeAllowedRoles)], controller.delete);
};