// routes/productcomponent.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize");
const controller = require("../controllers/productcomponent.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Aturan akses: Super, Manager, Admin, Operational
  const allowedRoles = ['Super', 'Manager', 'Admin', 'Operational'];

  // Endpoint untuk komponen produk
  app.route("/api/products/:productId/components")
    .get(
      [authJwt.verifyToken, authorize(allowedRoles)], // Bisa dilihat oleh role operasional
      controller.findAllForProduct
    );

  app.route("/api/product-components")
    .post(
      [authJwt.verifyToken, authorize(allowedRoles)], // Hanya role tertentu bisa create
      controller.create
    );

  app.route("/api/product-components/:id")
    .put(
      [authJwt.verifyToken, authorize(allowedRoles)], // Update
      controller.update
    )
    .delete(
      [authJwt.verifyToken, authorize(allowedRoles)], // Delete
      controller.delete
    );
};