// routes/category.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize"); // Import middleware otorisasi
const controller = require("../controllers/category.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Terapkan middleware authJwt.verifyToken dan authorize
  // Aturan akses Category (contoh: hanya Super, Manager, Admin yang bisa mengelola kategori)
  const categoryAllowedRoles = ['Super', 'Manager', 'Admin'];

  app.route("/api/categories")
    // CREATE Category: Super, Manager, Admin
    .post([authJwt.verifyToken, authorize(categoryAllowedRoles)], controller.create)
    // GET All Categories: Super, Manager, Admin (jika Guest bisa lihat, tambahkan 'Guest' ke array)
    .get([authJwt.verifyToken, authorize(categoryAllowedRoles)], controller.findAll)
    // DELETE All Categories: Hanya Super dan Admin (sesuaikan jika perlu)
    .delete([authJwt.verifyToken, authorize(['Super', 'Admin'])], controller.deleteAll);

  app.route("/api/categories/:id")
    // GET Single Category: Super, Manager, Admin (jika Guest bisa lihat, tambahkan 'Guest' ke array)
    .get([authJwt.verifyToken, authorize(categoryAllowedRoles)], controller.findOne)
    // UPDATE Category: Super, Manager, Admin
    .put([authJwt.verifyToken, authorize(categoryAllowedRoles)], controller.update)
    // DELETE Category: Super, Manager, Admin
    .delete([authJwt.verifyToken, authorize(categoryAllowedRoles)], controller.delete);
};