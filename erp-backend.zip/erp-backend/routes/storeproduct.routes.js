// erp-backend/routes/storeproduct.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize");
const controller = require("../controllers/storeproduct.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Define roles allowed to manage inventory (e.g., Super, Manager, Admin, Operational)
  const inventoryAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational'];
  // Define roles allowed to read inventory (could include Guest if you want stock to be public)
  const inventoryReadAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational', 'Guest'];


  // Routes for managing individual StoreProduct entries (stock for a specific product in a specific store)
  // CREATE: Add/Set stock for a product in a store. If exists, updates.
  app.route("/api/store-products")
    .post(
        [authJwt.verifyToken, authorize(inventoryAllowedRoles)],
        controller.create // This controller handles both create and update if entry exists
    );

  // READ (All or filtered by storeId/productId query params)
  // Example: GET /api/store-products?storeId=1  -> Get all stock for Store 1
  // Example: GET /api/store-products?productId=5 -> Get stock of Product 5 in all stores
  // Example: GET /api/store-products?storeId=1&productId=5 -> Get stock of Product 5 in Store 1 (similar to findOne but returns array)
   app.route("/api/store-products")
       .get(
           [authJwt.verifyToken, authorize(inventoryReadAllowedRoles)],
           controller.findAll
       );


  // Routes for specific StoreProduct entry by its ID (storeProductId)
  app.route("/api/store-products/:id")
    .get(
        [authJwt.verifyToken, authorize(inventoryReadAllowedRoles)],
        controller.findOne // READ single entry by storeProductId
    )
    .put(
        [authJwt.verifyToken, authorize(inventoryAllowedRoles)],
        controller.update // UPDATE quantity of a specific entry
    )
    .delete(
        [authJwt.verifyToken, authorize(inventoryAllowedRoles)],
        controller.delete // DELETE a specific entry
    );

   // Optional routes for deleting all entries for a store or product
   app.route("/api/stores/:storeId/store-products")
       .delete(
           [authJwt.verifyToken, authorize(inventoryAllowedRoles)], // Adjust roles if needed
           controller.deleteAllForStore
       );

   app.route("/api/products/:productId/store-products")
       .delete(
           [authJwt.verifyToken, authorize(inventoryAllowedRoles)], // Adjust roles if needed
           controller.deleteAllForProduct
       );

};