// erp-backend/routes/transaction.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize");
const controller = require("../controllers/transaction.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Tentukan peran yang diizinkan untuk mengelola transaksi (Create, Update, Delete)
  // Asumsi: Super, Manager, Admin, Operational bisa membuat/mengubah transaksi
  const transactionAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational'];

  // Tentukan peran yang diizinkan untuk melihat daftar atau detail transaksi (Read)
  // Asumsi: Selain yang bisa mengelola, Guest juga bisa melihat (sesuaikan jika perlu)
   const transactionReadAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational', 'Guest'];

   // Tentukan peran yang diizinkan untuk menghapus semua transaksi
   // Asumsi: Hanya Super dan Admin yang bisa melakukan penghapusan massal
   const transactionDeleteAllAllowedRoles = ['Super', 'Admin'];


  // Rute untuk mengelola daftar transaksi dan membuat transaksi baru
  app.route("/api/transactions")
    // CREATE Transaction: Hanya role yang diizinkan mengelola transaksi
    .post([authJwt.verifyToken, authorize(transactionAllowedRoles)], controller.create)
    // GET All Transactions: Hanya role yang diizinkan membaca transaksi (termasuk Guest)
    .get([authJwt.verifyToken, authorize(transactionReadAllowedRoles)], controller.findAll)
    // DELETE All Transactions: Hanya role yang diizinkan menghapus massal
    .delete([authJwt.verifyToken, authorize(transactionDeleteAllAllowedRoles)], controller.deleteAll);


  // Rute untuk mengelola transaksi tunggal berdasarkan ID
  app.route("/api/transactions/:id")
    // GET Single Transaction: Hanya role yang diizinkan membaca transaksi (termasuk Guest)
    .get([authJwt.verifyToken, authorize(transactionReadAllowedRoles)], controller.findOne)
    // UPDATE Transaction: Hanya role yang diizinkan mengelola transaksi
    .put([authJwt.verifyToken, authorize(transactionAllowedRoles)], controller.update)
    // DELETE Transaction: Hanya role yang diizinkan mengelola transaksi
    .delete([authJwt.verifyToken, authorize(transactionAllowedRoles)], controller.delete);

};