// erp-backend/routes/transactionproduct.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize");
const controller = require("../controllers/transactionproduct.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Tentukan peran yang diizinkan untuk mengelola item transaksi (Create, Update, Delete)
  // Asumsi: Sama dengan role yang bisa mengelola transaksi
  const transactionProductAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational'];

  // Tentukan peran yang diizinkan untuk melihat item transaksi (Read)
  // Asumsi: Sama dengan role yang bisa membaca transaksi (termasuk Guest)
   const transactionProductReadAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational', 'Guest'];


  // Rute untuk mendapatkan semua item produk untuk transaksi tertentu
  // GET /api/transactions/:transactionId/products
  app.route("/api/transactions/:transactionId/products")
      .get(
          [authJwt.verifyToken, authorize(transactionProductReadAllowedRoles)],
          controller.findAllForTransaction
      );
       // Opsional: Rute untuk menghapus semua item produk untuk transaksi tertentu
      // .delete(
      //     [authJwt.verifyToken, authorize(transactionProductAllowedRoles)], // Role yang diizinkan menghapus item
      //     controller.deleteAllForTransaction
      // );


  // Rute untuk mengelola item transaksi tunggal (Create, Read Detail, Update, Delete)
  app.route("/api/transaction-products")
      // CREATE TransactionProduct (menambahkan item ke transaksi yang sudah ada)
      .post(
          [authJwt.verifyToken, authorize(transactionProductAllowedRoles)],
          controller.create
      );

   app.route("/api/transaction-products/:id")
       // GET Single TransactionProduct by transactionProductId
       .get(
           [authJwt.verifyToken, authorize(transactionProductReadAllowedRoles)],
           controller.findOne
       )
       // UPDATE TransactionProduct by transactionProductId
       .put(
           [authJwt.verifyToken, authorize(transactionProductAllowedRoles)],
           controller.update
       )
       // DELETE TransactionProduct by transactionProductId
       .delete(
           [authJwt.verifyToken, authorize(transactionProductAllowedRoles)],
           controller.delete
       );
};