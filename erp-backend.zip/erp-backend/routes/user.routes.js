// routes/user.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize"); // Import middleware otorisasi
const controller = require("../controllers/user.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Terapkan middleware authJwt.verifyToken dan authorize
  // Sesuai aturan: Hanya Super yang bisa akses User CRUD
  const userAllowedRoles = ['Super'];
    // Untuk findAll (GET list) dan findOne (GET detail), hanya Super yang bisa akses
    const userReadAllowedRoles = ['Super'];
    // Untuk DELETE ALL, hanya Super
   const userDeleteAllAllowedRoles = ['Super'];


  app.route("/api/users")
    // CREATE User: Hanya Super
    .post([authJwt.verifyToken, authorize(userAllowedRoles)], controller.create)
    // GET All Users: Hanya Super
    .get([authJwt.verifyToken, authorize(userReadAllowedRoles)], controller.findAll)
    // DELETE All Users: Hanya Super
    .delete([authJwt.verifyToken, authorize(userDeleteAllAllowedRoles)], controller.deleteAll);

  app.route("/api/users/:id")
    // GET Single User: Hanya Super
    .get([authJwt.verifyToken, authorize(userReadAllowedRoles)], controller.findOne)
    // UPDATE User: Hanya Super
    .put([authJwt.verifyToken, authorize(userAllowedRoles)], controller.update)
    // DELETE User: Hanya Super
    .delete([authJwt.verifyToken, authorize(userAllowedRoles)], controller.delete); // Asumsi yang bisa delete per item sama dengan yang bisa create/update
};