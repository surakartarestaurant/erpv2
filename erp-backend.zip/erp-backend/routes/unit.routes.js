// routes/unit.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize");
const controller = require("../controllers/unit.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Aturan akses Unit (contoh: hanya Super, Manager, Admin yang bisa mengelola unit)
  const unitAllowedRoles = ['Super', 'Manager', 'Admin'];
  // Jika Guest bisa melihat daftar unit, tambahkan 'Guest' ke unitReadAllowedRoles
   const unitReadAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational', 'Guest']; // Asumsi unit bisa dilihat oleh semua role operasional

  app.route("/api/units")
    // CREATE Unit: Super, Manager, Admin
    .post([authJwt.verifyToken, authorize(unitAllowedRoles)], controller.create)
    // GET All Units: Super, Manager, Admin, Operational, Guest (sesuaikan role jika perlu)
    .get([authJwt.verifyToken, authorize(unitReadAllowedRoles)], controller.findAll)
    // DELETE All Units: Hanya Super dan Admin (sesuaikan jika perlu)
    .delete([authJwt.verifyToken, authorize(['Super', 'Admin'])], controller.deleteAll); // Sesuaikan role untuk deleteAll

  app.route("/api/units/:id")
    // GET Single Unit: Super, Manager, Admin, Operational, Guest (sesuaikan role jika perlu)
    .get([authJwt.verifyToken, authorize(unitReadAllowedRoles)], controller.findOne)
    // UPDATE Unit: Super, Manager, Admin
    .put([authJwt.verifyToken, authorize(unitAllowedRoles)], controller.update)
    // DELETE Unit: Super, Manager, Admin
    .delete([authJwt.verifyToken, authorize(unitAllowedRoles)], controller.delete);
};