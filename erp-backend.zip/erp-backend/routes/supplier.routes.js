// routes/supplier.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize"); // Import middleware otorisasi
const controller = require("../controllers/supplier.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Terapkan middleware authJwt.verifyToken dan authorize
  // Sesuai aturan: Super, Manager, Admin bisa akses Supplier
  const supplierAllowedRoles = ['Super', 'Manager', 'Admin'];
  // Untuk findAll (GET list) dan findOne (GET detail), Guest tidak termasuk Supplier berdasarkan aturan Anda
  const supplierReadAllowedRoles = ['Super', 'Manager', 'Admin'];
  // Untuk DELETE ALL, hanya Super dan Admin
   const supplierDeleteAllAllowedRoles = ['Super', 'Admin'];


  app.route("/api/suppliers")
    // CREATE Supplier: Super, Manager, Admin
    .post([authJwt.verifyToken, authorize(supplierAllowedRoles)], controller.create)
    // GET All Suppliers: Super, Manager, Admin
    .get([authJwt.verifyToken, authorize(supplierReadAllowedRoles)], controller.findAll)
    // DELETE All Suppliers: Super, Admin
    .delete([authJwt.verifyToken, authorize(supplierDeleteAllAllowedRoles)], controller.deleteAll);

  app.route("/api/suppliers/:id")
    // GET Single Supplier: Super, Manager, Admin
    .get([authJwt.verifyToken, authorize(supplierReadAllowedRoles)], controller.findOne)
    // UPDATE Supplier: Super, Manager, Admin
    .put([authJwt.verifyToken, authorize(supplierAllowedRoles)], controller.update)
    // DELETE Supplier: Super, Manager, Admin
    .delete([authJwt.verifyToken, authorize(supplierAllowedRoles)], controller.delete); // Asumsi yang bisa delete per item sama dengan yang bisa create/update
};