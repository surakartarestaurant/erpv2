// routes/productunit.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize");
const controller = require("../controllers/productunit.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Aturan akses ProductUnit (konversi unit per produk)
  // Asumsi role yang bisa mengelola Product (Super, Manager, Admin, Operational) bisa mengelola konversi unitnya juga.
  const productUnitAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational'];
  // Asumsi role yang bisa melihat detail Product (Super, Manager, Admin, Operational, Guest) bisa melihat konversi unitnya juga.
  const productUnitReadAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational', 'Guest'];

  // Route untuk mengelola konversi unit untuk produk tertentu
  // GET /api/products/:productId/units -> Mendapatkan semua konversi untuk produk tertentu
  // POST /api/product-units -> Menambah konversi baru (body: { productId, unitId, conversionFactor })
  // GET /api/product-units/:id -> Mendapatkan detail konversi tunggal (id = productUnitId)
  // PUT /api/product-units/:id -> Mengupdate konversi tunggal
  // DELETE /api/product-units/:id -> Menghapus konversi tunggal
  // DELETE /api/products/:productId/units -> Menghapus semua konversi untuk produk tertentu (Opsional)


  // GET all conversions for a specific product
  app.route("/api/products/:productId/units")
      .get([authJwt.verifyToken, authorize(productUnitReadAllowedRoles)], controller.findAllForProduct);
      // Opsional: DELETE all conversions for a specific product
      // .delete([authJwt.verifyToken, authorize(productUnitAllowedRoles)], controller.deleteAllForProduct); // Sesuaikan role jika perlu

  // CRUD for individual ProductUnit entries
  app.route("/api/product-units")
      .post([authJwt.verifyToken, authorize(productUnitAllowedRoles)], controller.create); // CREATE

  app.route("/api/product-units/:id")
      .get([authJwt.verifyToken, authorize(productUnitReadAllowedRoles)], controller.findOne) // READ single
      .put([authJwt.verifyToken, authorize(productUnitAllowedRoles)], controller.update)   // UPDATE
      .delete([authJwt.verifyToken, authorize(productUnitAllowedRoles)], controller.delete); // DELETE

};