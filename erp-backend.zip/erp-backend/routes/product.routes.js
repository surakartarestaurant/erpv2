// routes/product.routes.js
const authJwt = require("../middleware/authJwt");
const authorize = require("../middleware/authorize"); // Import middleware otorisasi
const controller = require("../controllers/product.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  // Terapkan middleware authJwt.verifyToken dan authorize
  // Sesuai aturan: Super, Manager, Admin, Operational bisa akses Product
  const productAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational'];
  // Untuk findAll (GET list) dan findOne (GET detail), Guest juga bisa akses
  const productReadAllowedRoles = ['Super', 'Manager', 'Admin', 'Operational', 'Guest'];
  // Untuk DELETE ALL, hanya Super dan Admin (sesuai contoh sebelumnya, jika diinginkan)
   const productDeleteAllAllowedRoles = ['Super', 'Admin'];


  app.route("/api/products")
    // CREATE Product: Super, Manager, Admin, Operational
    .post([authJwt.verifyToken, authorize(productAllowedRoles)], controller.create)
    // GET All Products: Super, Manager, Admin, Operational, Guest
    .get([authJwt.verifyToken, authorize(productReadAllowedRoles)], controller.findAll)
    // DELETE All Products: Super, Admin
    .delete([authJwt.verifyToken, authorize(productDeleteAllAllowedRoles)], controller.deleteAll);

  app.route("/api/products/:id")
    // GET Single Product: Super, Manager, Admin, Operational, Guest
    .get([authJwt.verifyToken, authorize(productReadAllowedRoles)], controller.findOne)
    // UPDATE Product: Super, Manager, Admin, Operational
    .put([authJwt.verifyToken, authorize(productAllowedRoles)], controller.update)
    // DELETE Product: Super, Manager, Admin, Operational
    .delete([authJwt.verifyToken, authorize(productAllowedRoles)], controller.delete); // Asumsi yang bisa delete per item sama dengan yang bisa create/update
};