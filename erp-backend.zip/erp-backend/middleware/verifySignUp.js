// middleware/verifySignUp.js
// Middleware ini bisa ditambahkan untuk validasi saat registrasi user baru
// Untuk saat ini, kita biarkan kosong atau tambahkan placeholder
const verifySignUp = {}; // Placeholder

module.exports = verifySignUp;