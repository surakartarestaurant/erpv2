// middleware/authorize.js
const db = require("../models");
const User = db.User;

/**
 * Middleware factory to check if the user's role is included in the allowed roles list.
 *
 * @param {string[]} allowedRoles - An array of roles that are allowed to access the resource.
 * @returns {function} - The middleware function.
 */
const authorize = (allowedRoles) => {
  return (req, res, next) => {
    // userId should be available from the previous authJwt.verifyToken middleware
    if (!req.userId) {
      return res.status(401).send({ message: "Unauthorized! User ID not found in request." });
    }

    User.findByPk(req.userId)
      .then(user => {
        if (!user) {
          return res.status(404).send({ message: "User Not found." });
        }

        // Check if the user's role is in the allowedRoles array
        if (allowedRoles.includes(user.role)) {
          next(); // User's role is allowed, proceed to the next middleware/controller
        } else {
          // User's role is not allowed
          res.status(403).send({
            message: `Forbidden! Requires one of the following roles: ${allowedRoles.join(', ')}. Your role is ${user.role}.`
          });
        }
      })
      .catch(err => {
        res.status(500).send({ message: err.message || "Error checking user role." });
      });
  };
};

module.exports = authorize;