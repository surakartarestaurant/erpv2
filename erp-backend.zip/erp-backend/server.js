// server.js
const express = require("express");
const cors = require("cors");
const db = require("./models");
require('dotenv').config();

const app = express();

// Middleware
var corsOptions = {
  origin: "http://localhost:3000" // Izinkan frontend React mengakses backend
};
app.use(cors(corsOptions));
// parse requests of content-type - application/json
app.use(express.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

// Sinkronisasi database
// Gunakan { force: true } hanya saat pengembangan untuk menghapus dan membuat ulang tabel
// Jika tabel categories dan ProductCategories sudah ada, Anda bisa gunakan { alter: true }
// HATI-HATI menggunakan { force: true } karena akan menghapus semua data!
db.sequelize.sync()
  .then(() => {
    console.log("Database synced successfully.");
    // Anda bisa tambahkan inisialisasi data awal di sini jika perlu
    // initial();
  })
  .catch((err) => {
    console.log("Failed to sync database: " + err.message);
  });

// Route sederhana
app.get("/", (req, res) => {
  res.json({ message: "Welcome to ERP backend application." });
});

// Routes
require("./routes/auth.routes")(app);
require("./routes/product.routes")(app);
require("./routes/supplier.routes")(app);
require("./routes/user.routes")(app);
require("./routes/category.routes")(app);
require("./routes/unit.routes")(app);
require("./routes/productunit.routes")(app);
require("./routes/productcomponent.routes")(app);
require("./routes/store.routes")(app);
require("./routes/storeproduct.routes")(app);
require("./routes/customer.routes")(app);
require("./routes/transaction.routes")(app);
require("./routes/transactionproduct.routes")(app);

// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});

// Fungsi untuk inisialisasi data awal (opsional)
// function initial() {
//   // Contoh: Membuat user admin pertama
//   const bcrypt = require("bcryptjs");
//   db.User.create({
//     username: "admin",
//     email: "admin@example.com",
//     password: bcrypt.hashSync("password123", 8)
//   });
// }