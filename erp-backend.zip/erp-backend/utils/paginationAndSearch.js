// erp-backend/utils/paginationAndSearch.js
const { Op } = require('sequelize');

/**
 * Generic function to handle pagination and searching for Sequelize models.
 *
 * @param {Object} model - The Sequelize model (e.g., db.Product, db.Supplier).
 * @param {Object} queryParams - The query parameters from the request (req.query).
 * @param {string[]} searchableFields - An array of field names to search within (e.g., ['product_name']).
 * @param {Object} [options={}] - Additional options for findAndCountAll (e.g., attributes, include, order).
 * @returns {Promise<Object>} - A promise that resolves with the paginated and searched data.
 */
const paginateAndSearch = async (model, queryParams, searchableFields, options = {}) => {
  const { page = 1, pageSize = 10, searchTerm = '' } = queryParams;
  const parsedPage = parseInt(page);
  const parsedPageSize = parseInt(pageSize);
  const offset = (parsedPage - 1) * parsedPageSize;
  const limit = parsedPageSize;

  let whereCondition = {};
  if (searchTerm && searchableFields && searchableFields.length > 0) {
    whereCondition[Op.or] = searchableFields.map(field => ({
      [field]: { [Op.iLike]: `%${searchTerm}%` } // Use Op.iLike for case-insensitive search (PostgreSQL)
    }));
  }

  try {
    const data = await model.findAndCountAll({
      where: whereCondition,
      limit: limit,
      offset: offset,
      order: options.order || [[model.primaryKeyAttributes[0], 'ASC']], // Use provided order or default to primary key
      attributes: options.attributes, // Include specified attributes
      include: options.include, // Include specified associations
      ...options // Spread any other options
    });

    return {
      items: data.rows,
      totalItems: data.count,
      currentPage: parsedPage,
      totalPages: Math.ceil(data.count / limit)
    };
  } catch (error) {
    console.error("Error in paginateAndSearch:", error);
    throw error; // Rethrow the error to be caught by the controller
  }
};

module.exports = paginateAndSearch;