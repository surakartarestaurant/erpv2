// erp-backend/utils/formatQuantity.js
const formatQuantity = (quantity) => {
  if (Number.isInteger(Number(quantity))) {
    return parseInt(quantity);
  } else {
    return Number(quantity).toString().replace(/0*$/, '');
  }
};

module.exports = formatQuantity;