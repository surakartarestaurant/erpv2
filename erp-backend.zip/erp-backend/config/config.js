// config/config.js
require('dotenv').config(); // Memuat variabel lingkungan dari .env

module.exports = {
  development: {
    username: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    host: process.env.DB_HOST,
    dialect: 'postgres',
    logging: false // Atur ke true jika ingin melihat query SQL di console
  },
  // Anda bisa tambahkan konfigurasi untuk production, test, dll.
  // production: { ... }
};